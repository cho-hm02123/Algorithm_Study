# **Project : Self-Driving Human Follower**

## **Features**

**PC** : Jetson AGX Xavior - Jetpack 5.0.2 / Ubuntu 20.04

**PLATFORM** : Jackal without NUC(Instead, use AGX)

**MAIN SENSOR** : RGB-D Camera(ZED2), Lidar()

**OTHER** : Servo Motor(Dynamixel MX-64) & OpenCR1.0

---

## **Install VScode**

- [Here's the link](https://code.visualstudio.com/docs/setup/linux)

- 'ros/ros.h' including error Solution

  - Execute VScode and press F1, then click 'C/C++:Select a Configuration...'.

  - if 'c_cpp_properties.json' inside '.vscode' created, you add the next line at 'includePath'.

  ```bash
  "/opt/ros/noetic/include"
  ``` 

  - then, you can see 'c_cpp_properties.json' looks like the next.

  ```bash
   {
      "configurations": [
          {
              "name": "Linux",
              "includePath": [
                  "${workspaceFolder}/**",
                  "/opt/ros/noetic/include"
              ],
              "defines": [],
              "compilerPath": "/usr/bin/gcc",
              "cStandard": "c17",
              "cppStandard": "gnu++14",
              "intelliSenseMode": "linux-gcc-arm64"
          }
      ],
      "version": 4
  }
  ```
---

## **Configuration Settings**

- [Here's the document with Settings](./docs/SETTINGS.md)

---

## **Bracket**

- Added urdf for that modeling to combine jackal and zed bracket

    - At [urdf/jackal.urdf.xacro](/urdf/jackal.urdf.xacro), zed_bracket's parameter **horizontal** is horizontal view of zed

    - Test to turn camera view(It's not horizontal view, it's camera view to decide from servo)   
    The data is radian

    ```bash
    $ rostopic pub /cam_position_controller/command std_msgs/Float64 "data: 0.0"
    ```

---

## **Click to Run**

1. Create a file named '*.desktop' in the desktop.

    ```bash
    $ cd ~/Desktop
    $ vim sdhf.desktop
    ```

    - [User] must be changed in the 'sdhf.desktop'

        ```bash
        [Desktop Entry]
        Version=1.0
        Type=Application
        Terminal=false
        Name=Self-Driving Human Follower
        Exec=gnome-terminal --profile='Hold Open' -- bash -i -c '/home/[User]/Desktop/sdhf.sh'
        Icon=gnome-terminal
        ```

    - Then, copy the file to /usr/share/applications

        ```bash
        $ sudo cp ~/Desktop/sdhf.desktop /usr/share/applications/sdhf.desktop
        ```

    - *Now, you can see the execution icon of SDHF*

2. Create a file named '*.sh' in the desktop

    ```bash
    $ cd ~/Desktop
    $ vim sdhf.sh
    ```

    - [Current IP] must be changed in the 'sdhf.sh'

        ```bash
        #!/bin/bash
        #sudo jetson_clocks --fan

        # Check if roscore is already running, if yes then kill it
        if (rosnode list &> /dev/null); then
            killall -9 roscore
            killall -9 rosmaster
        fi

        source ~/.bashrc

        export ROS_IP=[Current IP]
        export ROS_HOSTNAME=$ROS_IP

        roslaunch sdhf sdhf.launch

        read -p "Press Enter to close this window"
        ```

3. Clink the icon of SDHF

---

## How to Run?

   - Terminal 1
   ```bash
   $ roslaunch
   ```

   - Terminal 2
   ```bash
   $ rosrun
   ```

 ---