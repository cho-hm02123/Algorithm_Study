#include <cstring>
#include <csignal>

#include "ros/ros.h"
#include "ros/time.h"
#include "dynamixel_sdk/dynamixel_sdk.h"

#include "std_msgs/Float64.h"

using namespace std;

#define DXL_ID      1
#define DEVICENAME  "/dev/ttyUSB0"

#define PROTOCOL_VERSION    2.0

#define ADDR_TORQUE_ENABLE          64
#define ADDR_GOAL_POSITION          116
#define ADDR_PRESENT_POSITION       132
// Refer to the Minimum Position Limit of product eManual
#define MINIMUM_POSITION_LIMIT      0
// Refer to the Maximum Position Limit of product eManual
#define MAXIMUM_POSITION_LIMIT      4095
#define BAUDRATE                    57600

#define TORQUE_ENABLE                   1
#define TORQUE_DISABLE                  0
// DYNAMIXEL moving status threshold
#define DXL_MOVING_STATUS_THRESHOLD     20
#define ESC_ASCII_VALUE                 0x1b

#define MIDDLE_POSITION                 2048
#define COEFFIECIENT_POS_DIV_ANGLE      651.89864690440329530934789477382
#define COEFFIECIENT_ANGLE_DIV_POS      0.00153398078788564122971808758949

#define PERIOD 50

#define P_GAIN  0.0875
#define I_GAIN  0.0
#define D_GAIN  0.15

#define I_LIMIT 2

//==========================================================================//
// Class
//==========================================================================//
class DynamixelControlling
{
private:
    // Structures
    struct Dxl {
        // Initialize PortHandler instance
        // Set the port path
        // Get methods and members of PortHandlerLinux or PortHandlerWindows
        dynamixel::PortHandler *portHandler;
        // Initialize PacketHandler instance
        // Set the protocol version
        // Get methods and members of Protocol1PacketHandler or Protocol2PacketHandler
        dynamixel::PacketHandler *packetHandler;

        // Communication result
        int comm_result;
        // Read 4 byte Position data
        int32_t present_position;
        // DYNAMIXEL error
        uint8_t error;
    };

    struct SerialPort {
        std::string port;
        int baudrate;
    };

    // Node handle
    ros::NodeHandle nh_;

    // Msgs
    std_msgs::Float64 cmd_drive_msg_;

    // Variables
    Dxl dxl_;
    SerialPort serial_;

    double tar_pos_;
    double err_[4];
    double integral_term_;

    // Publisher
    ros::Publisher feedback_pub_;

    // Subscriber
    ros::Subscriber cmd_drive_sub_;

public:
    int rtn_;

    DynamixelControlling(std::string port, int baudrate);
    ~DynamixelControlling();

    void cmdDriveCallback(const std_msgs::Float64::ConstPtr& cmd_drive_msg);

    int connectDynamixel();
    void disconnectDynamixel();
    void controlMotor();

    void feedbackPulish();
};
//==========================================================================//
// Class Constructor & Destructor
//==========================================================================//
DynamixelControlling::DynamixelControlling(std::string port, int baudrate)
{
    //Subscriber
    cmd_drive_sub_ = nh_.subscribe(
        "/servo_cmd_drive", 1, &DynamixelControlling::cmdDriveCallback, this);

    //Publisher
    feedback_pub_ = nh_.advertise<std_msgs::Float64>("/servo_feedback", 1);

    //Variable
    serial_.port = port;
    serial_.baudrate = baudrate;
    
    dxl_.portHandler = dynamixel::PortHandler::getPortHandler(
        serial_.port.c_str());
    dxl_.packetHandler = dynamixel::PacketHandler::getPacketHandler(
        PROTOCOL_VERSION);
    
    dxl_.comm_result = COMM_TX_FAIL;
    dxl_.error = 0;
    dxl_.present_position = 0;

    cmd_drive_msg_.data = 0;

    rtn_ = connectDynamixel();

//==========================================================================//

    dxl_.comm_result = dxl_.packetHandler->read4ByteTxRx(
        dxl_.portHandler,
        DXL_ID,
        ADDR_PRESENT_POSITION,
        (uint32_t*)&dxl_.present_position,
        &dxl_.error);

    if (dxl_.comm_result != COMM_SUCCESS)
        ROS_ERROR("%s", dxl_.packetHandler->getTxRxResult(dxl_.comm_result));
    else if (dxl_.error != 0)
        ROS_ERROR("%s", dxl_.packetHandler->getRxPacketError(dxl_.error));

    tar_pos_ = dxl_.present_position;
    memset(err_, 0, sizeof(err_));
    integral_term_ = 0;

    while(abs(dxl_.present_position - MIDDLE_POSITION) > 1)
        controlMotor();
}

DynamixelControlling::~DynamixelControlling()
{
    disconnectDynamixel();
}

//==========================================================================//
// Callback Function
//==========================================================================//
void DynamixelControlling::cmdDriveCallback(const std_msgs::Float64::ConstPtr& cmd_drive_msg)
{
    if(!cmd_drive_msg)
        return;
    
    cmd_drive_msg_ = *cmd_drive_msg;
}

//==========================================================================//
// Function
//==========================================================================//
int DynamixelControlling::connectDynamixel()
{
    // Open port
    if (dxl_.portHandler->openPort())
        ROS_INFO("Succeeded to open the port!");
    else
    {
        ROS_ERROR("%s : Failed to open the port!", serial_.port.c_str());
        dxl_.portHandler->closePort();
        return -1;
    }

    // Set port baudrate
    if (dxl_.portHandler->setBaudRate(serial_.baudrate))
        ROS_INFO("Succeeded to change the baudrate!");
    else
    {
        ROS_ERROR("Failed to change the baudrate!");
        dxl_.portHandler->closePort();
        return -1;
    }

    // Enable DYNAMIXEL Torque
    dxl_.comm_result = dxl_.packetHandler->write1ByteTxRx(
        dxl_.portHandler,
        DXL_ID,
        ADDR_TORQUE_ENABLE,
        TORQUE_ENABLE,
        &dxl_.error);

    if (dxl_.comm_result != COMM_SUCCESS)
        ROS_ERROR("%s", dxl_.packetHandler->getTxRxResult(dxl_.comm_result));
    else if (dxl_.error != 0)
        ROS_ERROR("%s", dxl_.packetHandler->getRxPacketError(dxl_.error));
    else
        ROS_INFO("Succeeded enabling DYNAMIXEL Torque.");

    return 0;
}

void DynamixelControlling::disconnectDynamixel()
{
    // Disable DYNAMIXEL Torque
    dxl_.comm_result = dxl_.packetHandler->write1ByteTxRx(
        dxl_.portHandler,
        DXL_ID,
        ADDR_TORQUE_ENABLE,
        TORQUE_DISABLE,
        &dxl_.error);

    if (dxl_.comm_result != COMM_SUCCESS)
        ROS_ERROR("%s", dxl_.packetHandler->getTxRxResult(dxl_.comm_result));
    else if (dxl_.error != 0)
        ROS_ERROR("%s", dxl_.packetHandler->getRxPacketError(dxl_.error));
    else
        ROS_INFO("Succeeded disabling DYNAMIXEL Torque.");

    // Close port
    dxl_.portHandler->closePort();
}

void DynamixelControlling::controlMotor()
{
    // Read the Present Position
    dxl_.comm_result = dxl_.packetHandler->read4ByteTxRx(
        dxl_.portHandler,
        DXL_ID,
        ADDR_PRESENT_POSITION,
        (uint32_t*)&dxl_.present_position,
        &dxl_.error);

    if (dxl_.comm_result != COMM_SUCCESS)
        ROS_ERROR("%s", dxl_.packetHandler->getTxRxResult(dxl_.comm_result));
    else if (dxl_.error != 0)
        ROS_ERROR("%s", dxl_.packetHandler->getRxPacketError(dxl_.error));

    double cur_pos = cmd_drive_msg_.data * COEFFIECIENT_POS_DIV_ANGLE + MIDDLE_POSITION;

    err_[3] = err_[2];
    err_[2] = err_[1];
    err_[1] = err_[0];
    err_[0] = cur_pos - dxl_.present_position;

    integral_term_ += err_[0] * I_GAIN;

    integral_term_ = integral_term_ > I_LIMIT ? I_LIMIT
                   : integral_term_ < -I_LIMIT ? -I_LIMIT
                   : integral_term_;

    tar_pos_ += err_[0] * P_GAIN + integral_term_ + (err_[0] - err_[1]) * D_GAIN;
 
    tar_pos_ = tar_pos_ > MAXIMUM_POSITION_LIMIT ? MAXIMUM_POSITION_LIMIT
             : tar_pos_ < MINIMUM_POSITION_LIMIT ? MINIMUM_POSITION_LIMIT
             : tar_pos_;

    // Write goal position
    dxl_.comm_result = dxl_.packetHandler->write4ByteTxRx(
        dxl_.portHandler,
        DXL_ID,
        ADDR_GOAL_POSITION,
        (int)tar_pos_,
        &dxl_.error);

    if (dxl_.comm_result != COMM_SUCCESS)
        ROS_ERROR("%s", dxl_.packetHandler->getTxRxResult(dxl_.comm_result));
    else if (dxl_.error != 0)
        ROS_ERROR("%s", dxl_.packetHandler->getRxPacketError(dxl_.error));
}

//==========================================================================//
// Publisher
//==========================================================================//
void DynamixelControlling::feedbackPulish()
{
    controlMotor();

    std_msgs::Float64 msg;
    msg.data = (dxl_.present_position - MIDDLE_POSITION) * COEFFIECIENT_ANGLE_DIV_POS;
    msg.data = msg.data > M_PI ? M_PI
             : msg.data < -M_PI ? -M_PI
             : msg.data;
    feedback_pub_.publish(msg);
}

//==========================================================================//
// Main
//==========================================================================//
int main(int argc, char **argv)
{
    ros::init(argc, argv, "dynamixel_controlling");

    std:string serial_port;
    int serial_baudrate;

    ros::NodeHandle nh_private("~");
    nh_private.param<std::string>("serial_port", serial_port, DEVICENAME);
    nh_private.param<int>("serial_baudrate", serial_baudrate, BAUDRATE); 

    DynamixelControlling dc(serial_port, serial_baudrate);
    ros::Rate loop_rate(PERIOD);

    if(dc.rtn_ != 0)
        return -1;
    
    while(ros::ok())
    {
        dc.feedbackPulish();

        ros::spinOnce();
		loop_rate.sleep();
    }

    dc.~DynamixelControlling();
    return 0;
}
