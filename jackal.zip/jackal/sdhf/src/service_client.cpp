#include <cstdlib>

#include "ros/ros.h"
#include "sdhf/UserChanger.h"

int main(int argc, char **argv)
{
    ros::init(argc, argv, "service_client");

    if(argc != 3)
    {
        ROS_ERROR("[Service Client]: Wrong arguments");
        ROS_ERROR("[Service Client]: arg0 : int16 number");

        return 1;
    }

    ros::NodeHandle nh;
    ros::ServiceClient client =
        nh.serviceClient<sdhf::UserChanger>("user_changer");

    sdhf::UserChanger uc_srv;
    uc_srv.request.label_id = atoll(argv[1]);

    if(client.call(uc_srv))
    {
        ROS_ERROR("[Service client]: Send srv, uc_srv(arg0) : %d", 
                 uc_srv.request.label_id);
    }
    else
    {
        ROS_ERROR("[Service Client]: Failed to call service");
        return 1;
    }
    return 0;
}
