#include "ros/ros.h"

#include "geometry_msgs/PoseStamped.h"
#include "nav_msgs/Odometry.h"

class Pose2OdomConverter 
{
private:
    ros::NodeHandle nh_;

    nav_msgs::Odometry odom_msg_;

    ros::Subscriber pose_sub_;
    ros::Publisher odom_pub_;

public:
    Pose2OdomConverter()
    {
        pose_sub_ = nh_.subscribe(
            "/tracked_pose", 1, &Pose2OdomConverter::poseCallback, this);
        odom_pub_ = nh_.advertise<nav_msgs::Odometry>("/tracked_odom", 1);
    }

    ~Pose2OdomConverter(){}

    void poseCallback(const geometry_msgs::PoseStamped::ConstPtr& pose_msg)
    {
        if(!pose_msg)
            return;

        odom_msg_.pose.pose.position = pose_msg->pose.position;
        odom_msg_.pose.pose.orientation = pose_msg->pose.orientation;

        odom_pub_.publish(odom_msg_);
    }
};

int main(int argc, char **argv)
{
    ros::init(argc, argv, "converter_p2o");
    Pose2OdomConverter ptoc;
    
    ros::spin();

	return 0;
}