#include <cmath>

#include "angle_conversion.h"

#include "ros/ros.h"

#include "sensor_msgs/LaserScan.h"

class ScanConverter 
{
private:
    ros::NodeHandle nh_;

    ros::Subscriber scan_sub_;
    ros::Publisher scan_pub_;

public:
    ScanConverter()
    {
        scan_sub_ = nh_.subscribe("/scan", 1, &ScanConverter::scanCallback, this);
        scan_pub_ = nh_.advertise<sensor_msgs::LaserScan>("/trans_scan", 1);
    }

    ~ScanConverter(){}

    void scanCallback(sensor_msgs::LaserScan scan_msg)
    {
        int size = scan_msg.ranges.size();
        double angle_per_size = 360. / (double)size;
        for(int i = 0; i < size; i++)
        {
            //double cur_angle = 180 - (double)i * angle_per_size; <- simulation
            double cur_angle = (double)i * angle_per_size;
            ANGLE2_RESTRICTION(cur_angle);
            
            if(cur_angle > 90 && cur_angle < 270)
            {
                double front_limit_dist = (-1.2) / cos(cur_angle * M_PI / 180);

                if(scan_msg.ranges[i] > front_limit_dist)
                {
                    /*
                    if(cur_angle > 150 && cur_angle < 210)
                        scan_msg.ranges[i] = 13.;//std::numeric_limits<float>::infinity();
                    else
                    */
                    scan_msg.ranges[i] = 12.;
                }
            }
            else if(cur_angle < 90 || cur_angle > 270)
            {
                double rear_limit_dist = 10.8 / cos(cur_angle * M_PI / 180);

                if(scan_msg.ranges[i] > rear_limit_dist)
                    scan_msg.ranges[i] = 12.;
            }
        }

        scan_pub_.publish(scan_msg);
    }
};

int main(int argc, char **argv)
{
    ros::init(argc, argv, "converter_scan");
    ScanConverter sc;

	ros::spin();

	return 0;
}