#include <deque>
#include <cmath>
#include <cstring>

#include "ros/ros.h"
#include "ros/time.h"

#include "angle_conversion.h"

#include "geometry_msgs/Twist.h"
#include "geometry_msgs/PoseStamped.h"
#include "geometry_msgs/Point.h"
#include "geometry_msgs/Quaternion.h"

#include "nav_msgs/Path.h"
#include "nav_msgs/Odometry.h"

#include "std_msgs/Bool.h"
#include "std_msgs/String.h"

using namespace std;

struct StateVariables {
    double x, y, th;
};

#define MAX_V 1.57
#define MAX_A 1.57

//==========================================================================//
// Class
//==========================================================================//
class Controller
{
private:
    ros::NodeHandle nh_;

    ros::Subscriber path_sub_;
    ros::Subscriber velo_sub_;
    ros::Subscriber pose_sub_;
    ros::Subscriber btn_move_sub_;

    ros::Publisher velo_pub_;
    ros::Publisher log_pub_;

    nav_msgs::Path path_msg_;
    deque<geometry_msgs::Twist> velo_msg_;
    StateVariables pose_msg_;

    deque<StateVariables> state_;

    double k1_[2][3], k2_[2][3];
    bool move_onoff;

public:
    Controller(bool simulation);
    ~Controller();

    void pathCallback(const nav_msgs::Path::ConstPtr& path_msg);
    void veloCallback(const geometry_msgs::Twist::ConstPtr& velo_msg);
    void poseCallback(const nav_msgs::Odometry::ConstPtr& pose_msg);
    void btnMoveCallback(const std_msgs::Bool::ConstPtr& btn_msg);

    StateVariables transform_x_y_th(const geometry_msgs::Pose& pose);
    
    void calu_velo();
};

//==========================================================================//
// Class Constructor & Destructor
//==========================================================================//
Controller::Controller(bool simulation)
{
    //Subscriber
    path_sub_ = nh_.subscribe(
        "/move_base/TrajectoryPlannerROS/local_plan", 1,
        &Controller::pathCallback, this);
    velo_sub_ = nh_.subscribe(
        "/move_base/cmd_vel", 1, &Controller::veloCallback, this);
    pose_sub_ = nh_.subscribe(
        "/tracked_odom", 1, &Controller::poseCallback, this);
    btn_move_sub_ = nh_.subscribe(
        "/btn/move", 2, &Controller::btnMoveCallback, this);
    
    //Publisher
    velo_pub_ = nh_.advertise<geometry_msgs::Twist>("/cmd_vel", 1);
    log_pub_ = nh_.advertise<std_msgs::String>("/log/path_tracking", 1);

    double k1[2][3] = {
    { 0.4245,-0.0000,-0.0000},
    { 0.0000, 1.1561, 0.8503}
    };
    memcpy(k1_, k1, sizeof(k1_));
    
    double k2[2][3] = {
    { 0.4245,-0.0000, 0.0000},
    {-0.0000,-1.1561, 0.8503}
    };
    memcpy(k2_, k2, sizeof(k2_));

    move_onoff = simulation;
}

Controller::~Controller(){}

//==========================================================================//
// Callback Function
//==========================================================================//
void Controller::pathCallback(const nav_msgs::Path::ConstPtr& path_msg)
{
    state_.clear();

    if(!path_msg)
        return;

    for(int i = 0; i < path_msg->poses.size(); i++)
        state_.push_back(transform_x_y_th(path_msg->poses[i].pose));
}

void Controller::veloCallback(const geometry_msgs::Twist::ConstPtr& velo_msg)
{
    velo_msg_.clear();

    if(!velo_msg)
        return;

    velo_msg_.push_back(*velo_msg);
}

void Controller::poseCallback(const nav_msgs::Odometry::ConstPtr& pose_msg)
{
    if(!pose_msg)
        return;

    pose_msg_ = transform_x_y_th(pose_msg->pose.pose);
}

void Controller::btnMoveCallback(const std_msgs::Bool::ConstPtr& btn_msg)
{
    if(!btn_msg)
        return;

    if(btn_msg->data)
    {
        if(move_onoff)
            move_onoff = false;
        else
            move_onoff = true;
    }
}

//==========================================================================//
// Publisher
//==========================================================================//
void Controller::calu_velo()
{
    double u[2] = { 0, };
    deque<StateVariables> tar;
    
    if(state_.size())
    {
        tar.push_back(state_.front());
        state_.pop_front();
    }

    if(move_onoff)
    {
        double vc[2];
        if(!velo_msg_.empty())
        {
            vc[0] = velo_msg_.front().linear.x;
            vc[1] = velo_msg_.front().angular.z;
        }
        else
        {
            vc[0] = 0;
            vc[1] = 0;
        }
        
        if(tar.empty())
            memcpy(u, vc, sizeof(u));
        else
        {
            double x[3] = {
                tar.front().x - pose_msg_.x,
                tar.front().y - pose_msg_.y,
                tar.front().th - pose_msg_.th
            };
            ANGLE2_RESTRICTION(x[2]);

            double xe[3][3] = {
                {cos(pose_msg_.th),  sin(pose_msg_.th), 0},
                {-sin(pose_msg_.th), cos(pose_msg_.th), 0},
                {0,                  0,                 1}
            };

            double xee[3] = { 0, };
            for(int i = 0; i < 3; i++)
                for(int j = 0; j < 3; j++)
                    xee[i] += x[j] * xe[i][j];
        
            //ROS_INFO("x_e: %+2.6lf y_e: %+2.6lf th_e: %+2.6lf", xee[0], xee[1], xee[2]);

            double member_func[2];
            member_func[0] = (MAX_V + vc[1]) / MAX_V * 0.5;
            member_func[1] = (MAX_V - vc[1]) / MAX_V * 0.5;
            double mem_sum = member_func[0] + member_func[1];

            double fuzzy_func[2][3];
            for(int i = 0; i < 2; i++)
                for(int j = 0; j < 3; j++)
                    fuzzy_func[i][j] = (member_func[0] * k1_[i][j] +
                                        member_func[1] * k2_[i][j]) / mem_sum;

            for(int i = 0; i < 2; i++)
                for(int j = 0; j < 3; j++)
                    u[i] += fuzzy_func[i][j] * xee[j];
            
            u[0] += vc[0];
            u[1] += vc[1];
        }

        geometry_msgs::Twist velo;
        velo.linear.x = u[0];
        velo.angular.z = u[1];

        velo_pub_.publish(velo);
    }
    
    ROS_INFO("linear: %lf | angular: %lf", u[0], u[1]);

    // log generator
    static string logic_box[2] = {"false", "true"};
    static std_msgs::String log_msg;
    log_msg.data = (("move onoff: " + logic_box[move_onoff]));
    log_pub_.publish(log_msg);
}

//==========================================================================//
// Functions
//==========================================================================//
StateVariables Controller::transform_x_y_th(
    const geometry_msgs::Pose& pose)
{
    const geometry_msgs::Point& p = pose.position;
    const geometry_msgs::Quaternion& q = pose.orientation;

    EulerAngles e = ToEulerAngles({q.x, q.y, q.z, q.w});

    return {p.x, p.y, e.yaw};
}

//==========================================================================//
// Main
//==========================================================================//
int main(int argc, char **argv)
{
    ros::init(argc, argv, "controller");

    bool simulation;

    ros::NodeHandle nh_private("~");
    nh_private.param<bool>("simulation", simulation, false);

    Controller ctrl(simulation);
    ros::Rate loop_rate(10);

    while(ros::ok())
    {
        ctrl.calu_velo();
        
        ros::spinOnce();
		loop_rate.sleep();
	}

    return 0;
}