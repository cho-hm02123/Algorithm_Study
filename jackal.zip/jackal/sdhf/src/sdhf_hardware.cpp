#include <string>
#include <cmath>

#include <boost/assign.hpp>
#include <boost/asio/io_service.hpp>
#include <boost/thread.hpp>
#include <boost/chrono.hpp>

#include "controller_manager/controller_manager.h"
#include "realtime_tools/realtime_publisher.h"
#include "ros/ros.h"
#include "rosserial_server/serial_session.h"

#include "hardware_interface/joint_command_interface.h"
#include "hardware_interface/joint_state_interface.h"
#include "hardware_interface/robot_hw.h"

#include "jackal_base/jackal_diagnostic_updater.h"

#include "jackal_msgs/Drive.h"
#include "jackal_msgs/Feedback.h"
#include "std_msgs/Float64.h"
#include "sensor_msgs/JointState.h"

typedef boost::chrono::steady_clock time_source;

class SdhfRobotHw : public hardware_interface::RobotHW
{
private:
    ros::NodeHandle nh_;

    ros::Subscriber feedback_sub_;
    ros::Subscriber servo_feedback_sub_;
    realtime_tools::RealtimePublisher<jackal_msgs::Drive> cmd_drive_pub_;
    realtime_tools::RealtimePublisher<std_msgs::Float64> servo_cmd_drive_pub_;

    hardware_interface::JointStateInterface joint_state_interface_;
    hardware_interface::VelocityJointInterface velocity_joint_interface_;
    hardware_interface::PositionJointInterface position_joint_interface_;

    struct Joint
    {
        double position;
        double velocity;
        double effort;
        double velocity_command;
        double position_command;
        double position_offset;

        Joint() : position(0),
                  velocity(0),
                  effort(0),
                  velocity_command(0),
                  position_command(0),
                  position_offset(std::numeric_limits<double>::quiet_NaN())
        {
        }
    }
    joints_[5];

    unsigned int servo_num_;

    // This pointer is set from the ROS thread.
    jackal_msgs::Feedback::ConstPtr feedback_msg_;
    std_msgs::Float64::ConstPtr servo_feedback_msg_;
    boost::mutex feedback_msg_mutex_;
    boost::mutex servo_feedback_msg_mutex_;

public:
    SdhfRobotHw()
    {
        ros::V_string joint_names = boost::assign::list_of("front_left_wheel")
            ("front_right_wheel")("rear_left_wheel")("rear_right_wheel");

        unsigned int i;
        for (i = 0; i < joint_names.size(); i++)
        {
            hardware_interface::JointStateHandle joint_state_handle(
                joint_names[i],
                &joints_[i].position,
                &joints_[i].velocity,
                &joints_[i].effort);
            joint_state_interface_.registerHandle(joint_state_handle);

            hardware_interface::JointHandle joint_handle(
                joint_state_handle, &joints_[i].velocity_command);
            velocity_joint_interface_.registerHandle(joint_handle);
        }
        servo_num_ = i;

        hardware_interface::JointStateHandle joint_state_handle(
            "bracket1_joint",
            &joints_[servo_num_].position,
            &joints_[servo_num_].velocity,
            &joints_[servo_num_].effort);
        joint_state_interface_.registerHandle(joint_state_handle);

        hardware_interface::JointHandle joint_handle(
            joint_state_handle, &joints_[servo_num_].position_command);
        position_joint_interface_.registerHandle(joint_handle);
           
        registerInterface(&joint_state_interface_);
        registerInterface(&velocity_joint_interface_);
        registerInterface(&position_joint_interface_);

        feedback_sub_ = nh_.subscribe(
            "feedback", 1, &SdhfRobotHw::feedbackCallback, this);
        servo_feedback_sub_ = nh_.subscribe(
            "servo_feedback", 1, &SdhfRobotHw::crFeedbackCallback, this);

        // Realtime publisher, initializes differently from regular ros::Publisher
        cmd_drive_pub_.init(nh_, "cmd_drive", 1);
        servo_cmd_drive_pub_.init(nh_, "servo_cmd_drive", 1);
    }

    ~SdhfRobotHw() {}

    void copyJointsFromHardware()
    {
        boost::mutex::scoped_lock feedback_msg_lock(feedback_msg_mutex_, boost::try_to_lock);
        if (feedback_msg_ && feedback_msg_lock)
        {
            for (int i = 0; i < 4; ++i)
            {
                const int j = i % 2;

                if (std::isnan(joints_[i].position_offset))
                {
                    joints_[i].position_offset = feedback_msg_->drivers[j].measured_travel;
                }

                joints_[i].position = feedback_msg_->drivers[j].measured_travel - joints_[i].position_offset;
                joints_[i].velocity = feedback_msg_->drivers[j].measured_velocity;
                joints_[i].effort = 0;  // TODO(mikepurvis): determine this from amperage data.
            }
        }
    }

    void publishDriveFromController()
    {
        if (cmd_drive_pub_.trylock())
        {
            cmd_drive_pub_.msg_.mode = jackal_msgs::Drive::MODE_VELOCITY;
            cmd_drive_pub_.msg_.drivers[jackal_msgs::Drive::LEFT] = joints_[0].velocity_command;
            cmd_drive_pub_.msg_.drivers[jackal_msgs::Drive::RIGHT] = joints_[1].velocity_command;
            cmd_drive_pub_.unlockAndPublish();
        }
    }

    void feedbackCallback(const jackal_msgs::Feedback::ConstPtr& msg)
    {
        boost::mutex::scoped_lock lock(feedback_msg_mutex_);
        feedback_msg_ = msg;
    }

    void crCopyJointsFromHardware()
    {
        boost::mutex::scoped_lock feedback_msg_lock(servo_feedback_msg_mutex_, boost::try_to_lock);
        if (servo_feedback_msg_ && feedback_msg_lock)
        {
            joints_[servo_num_].position = servo_feedback_msg_->data;
            joints_[servo_num_].velocity = 0;
            joints_[servo_num_].effort = 0;
        }
    }

    void crPublishDriveFromController()
    {
        if (servo_cmd_drive_pub_.trylock())
        {
            servo_cmd_drive_pub_.msg_.data = joints_[servo_num_].position_command;
            servo_cmd_drive_pub_.unlockAndPublish();
        }
    }

    void crFeedbackCallback(const std_msgs::Float64::ConstPtr& msg)
    {
        boost::mutex::scoped_lock lock(servo_feedback_msg_mutex_);
        servo_feedback_msg_ = msg;
    }
};

void controlThread(ros::Rate rate, SdhfRobotHw* robot, controller_manager::ControllerManager* cm)
{
    time_source::time_point last_time = time_source::now();

    while (1)
    {
        // Calculate monotonic time elapsed
        time_source::time_point this_time = time_source::now();
        boost::chrono::duration<double> elapsed_duration = this_time - last_time;
        ros::Duration elapsed(elapsed_duration.count());
        last_time = this_time;

        robot->copyJointsFromHardware();
        robot->crCopyJointsFromHardware();
        cm->update(ros::Time::now(), elapsed);
        robot->publishDriveFromController();
        robot->crPublishDriveFromController();
        rate.sleep();
    }
}

int main(int argc, char* argv[])
{
    ros::init(argc, argv, "sdhf_node");
    SdhfRobotHw sdhf;
    
    std::string port;
    ros::param::param<std::string>("~port", port, "/dev/jackal");
    boost::asio::io_service io_service;
    new rosserial_server::SerialSession(io_service, port, 115200);
    boost::thread(boost::bind(&boost::asio::io_service::run, &io_service));

    ros::NodeHandle controller_nh("");
    controller_manager::ControllerManager cm(&sdhf, controller_nh);
    boost::thread(boost::bind(controlThread, ros::Rate(50), &sdhf, &cm));

    jackal_base::JackalDiagnosticUpdater jackal_diagnostic_updater;

    ros::spin();

    return 0;
}