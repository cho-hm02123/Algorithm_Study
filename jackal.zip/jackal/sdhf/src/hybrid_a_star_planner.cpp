#include <cstring>
#include <vector>
#include <queue>

#include "ros/ros.h"

#include "nav_msgs/Odometry.h"
#include "geometry_msgs/PoseStamped.h"
#include "nav_msgs/OccupancyGrid.h"
#include "nav_msgs/MapMetaData.h"
#include "nav_msgs/Path.h"

#include "angle_conversion.h"

using namespace std;

//==========================================================================//
// Class
//==========================================================================//
class Planner
{
private:
    struct Coordinate {
        int x, y;
    };

    struct PQType {
        Coordinate position;
        Quaternion orientation;
        long long score;
    };

    struct Compare {
        bool operator()(PQType& a, PQType& b) {
            return a.score < b.score;
        }
    };

    ros::NodeHandle nh_;

    ros::Subscriber odom_sub_;
    ros::Subscriber goal_sub_;
    ros::Subscriber map_sub_;

    ros::Publisher path_pub_;

    nav_msgs::Odometry odom_msg_;
    geometry_msgs::PoseStamped goal_msg_;
    nav_msgs::OccupancyGrid map_msg_;
    nav_msgs::Path path_msg_;

    int dx_[8], dy_[8];

public:
    Planner();
    ~Planner();

    void odomCallback(const nav_msgs::Odometry& odom_msg);
    void goalCallback(const geometry_msgs::PoseStamped& goal_msg);
    void mapCallback(const nav_msgs::OccupancyGrid& map_msg);

    void pathPublisher();

    long long functionG(const nav_msgs::OccupancyGrid& map_msg, const Coordinate& next_node);
    long long functionH(const Coordinate& current, const Coordinate& goal);
    Quaternion robotMotion(const Quaternion& orientation,
        const Coordinate& current, const Coordinate& next, const nav_msgs::MapMetaData& map_info);
};

//==========================================================================//
// Class Constructor & Destructor
//==========================================================================//
Planner::Planner()
{
    odom_sub_ = nh_.subscribe("/tracked_odom", 1, &Planner::odomCallback, this);
    goal_sub_ = nh_.subscribe("/move_base_simple/goal", 1, &Planner::goalCallback, this);
    map_sub_ = nh_.subscribe("/map", 1, &Planner::mapCallback, this);

    path_pub_ = nh_.advertise<nav_msgs::Path>("/hybrid_a_star_planner/path", 1);

    path_msg_.header.frame_id = "map";

    int dx[8] = {1, 1, 0, -1, -1, -1,  0,  1};
    int dy[8] = {0, 1, 1,  1,  0, -1, -1, -1};
    memcpy(dx_, dx, sizeof(dx_));
    memcpy(dy_, dy, sizeof(dy_));
}

Planner::~Planner() {}

//==========================================================================//
// Callback Function
//==========================================================================//
void Planner::odomCallback(const nav_msgs::Odometry& odom_msg)
{
    odom_msg_ = odom_msg;
}
void Planner::goalCallback(const geometry_msgs::PoseStamped& goal_msg)
{
    goal_msg_ = goal_msg;
}
void Planner::mapCallback(const nav_msgs::OccupancyGrid& map_msg)
{
    map_msg_ = map_msg;
}

//==========================================================================//
// Functions
//==========================================================================//
void Planner::pathPublisher()
{
    const nav_msgs::MapMetaData& map_info = map_msg_.info;

    if((map_info.height + map_info.width) == 0)
    {
        ROS_ERROR("There is no map topic.");
        return;
    }

    Coordinate start_node = {
        (int)round((odom_msg_.pose.pose.position.x - map_info.origin.position.x) / map_info.resolution),
        (int)round((odom_msg_.pose.pose.position.y - map_info.origin.position.y) / map_info.resolution)
    };

    Coordinate goal_node = {
        (int)round((goal_msg_.pose.position.x - map_info.origin.position.x) / map_info.resolution),
        (int)round((goal_msg_.pose.position.y - map_info.origin.position.y) / map_info.resolution)
    };

    if(start_node.x < 0 || start_node.x >= map_info.width || start_node.y < 0 || start_node.y >= map_info.height)
    {
        ROS_ERROR("Out of range : start point");
        return;
    }

    if(goal_node.x < 0 || goal_node.x >= map_info.width || goal_node.y < 0 || goal_node.y >= map_info.height)
    {
        ROS_ERROR("Out of range : goal point");
        return;
    }

    struct PathGridMap {
        Coordinate node, close;
        long long score;
    };

    vector<PathGridMap> path_grid_map[map_info.height][map_info.width];
    priority_queue<PQType, vector<PQType>, Compare> pq;

    Quaternion odom_q = {
        odom_msg_.pose.pose.orientation.x,
        odom_msg_.pose.pose.orientation.y,
        odom_msg_.pose.pose.orientation.z,
        odom_msg_.pose.pose.orientation.w
    };

    while(!pq.empty())
        pq.pop();

    //pq.push({start_node, odom_msg_, functionG(odom_msg_, start_node, start_node) + functionH(start_node, goal_node)});
    pq.push({start_node, odom_q, 1000000000});
    path_grid_map[start_node.y][start_node.x].push_back({start_node, start_node, 1000000000});
    
    //ROS_INFO("Search Start. Start: %d, %d , Goal: %d, %d", start_node.x, start_node.y, goal_node.x, goal_node.y);

    while(!pq.empty())
    {
        PQType node = pq.top();
        pq.pop();

        const Coordinate curr_node = {node.position.x, node.position.y};

        if(curr_node.x == goal_node.x && curr_node.y == goal_node.y)
            break;

        for(int i = 0; i < 8; i++)
        {
            const Coordinate next_node = {curr_node.x + dx_[i], curr_node.y + dy_[i]};

            if(next_node.x < 0 || next_node.x >= map_info.width)
                continue;

            if(next_node.y < 0 || next_node.y >= map_info.height)
                continue;

            long long score = functionG(map_msg_, next_node) + functionH(next_node, goal_node); 
            //long long score = functionH(next_node, goal_node); 
            //if(score > node.score)
            //    continue;

            if(path_grid_map[next_node.y][next_node.x].size())
            {
                if(path_grid_map[next_node.y][next_node.x].back().close.x == curr_node.x
                    && path_grid_map[next_node.y][next_node.x].back().close.y == curr_node.y)
                    continue;
                /*
                if(node.score > path_grid_map[next_node.y][next_node.x].back().score)
                    continue;
                
                if(score >= path_grid_map[next_node.y][next_node.x].back().score)
                    continue;
                */
                if(path_grid_map[next_node.y][next_node.x].size() > path_grid_map[curr_node.y][curr_node.x].size() + 1)
                {
                    Quaternion next_ori = robotMotion(node.orientation, curr_node, next_node, map_info);
                    pq.push({next_node, next_ori, score});

                    if(path_grid_map[curr_node.y][curr_node.x].size())
                        path_grid_map[next_node.y][next_node.x] = path_grid_map[curr_node.y][curr_node.x];

                    path_grid_map[next_node.y][next_node.x].push_back({next_node, curr_node, score});
                }
            }
            else
            {
                Quaternion next_ori = robotMotion(node.orientation, curr_node, next_node, map_info);
                pq.push({next_node, next_ori, score});
    
                if(path_grid_map[curr_node.y][curr_node.x].size())
                        path_grid_map[next_node.y][next_node.x] = path_grid_map[curr_node.y][curr_node.x];
                
                path_grid_map[next_node.y][next_node.x].push_back({next_node, curr_node, score});
            }
        }
    }

    //ROS_INFO("Search Finish. Path size: %ld", path_grid_map[goal_node.y][goal_node.x].size());

    path_msg_.poses.clear();
    geometry_msgs::PoseStamped curr;
    curr.header.frame_id = path_msg_.header.frame_id;
    curr.pose.position.z = 0;
    
    int size = path_grid_map[goal_node.y][goal_node.x].size();
    for(int i = 0; i < size; i++)
    {
        curr.pose.position.x = path_grid_map[goal_node.y][goal_node.x][i].node.x * map_info.resolution + map_info.origin.position.x;
        curr.pose.position.y = path_grid_map[goal_node.y][goal_node.x][i].node.y * map_info.resolution + map_info.origin.position.y;
        path_msg_.poses.push_back(curr);
    }

    path_pub_.publish(path_msg_);
}

long long Planner::functionG(const nav_msgs::OccupancyGrid& map_msg, const Coordinate& next_node)
{
    long long limit = LONG_LONG_MAX >> 1;

    long long rtn = map_msg.data[map_msg.info.width * next_node.y + next_node.x];;
    if(rtn < 0)
        rtn = 75;
    else if(rtn > 75)
        return limit;
    
    for(int i = 0; i < 8; i++)
    {
        Coordinate curr = {next_node.x + dx_[i], next_node.y + dy_[i]};

        if(curr.x < 0 || curr.x >= map_msg.info.width)
            return limit;

        if(curr.y < 0 || curr.y >= map_msg.info.height)
            return limit;

        long long temp = map_msg.data[map_msg.info.width * curr.y + curr.x];
        //ROS_INFO_STREAM(temp << " " << rtn);
        if(temp < 0)
            rtn += 75;
        else if(temp > 75)
            return limit;
        else
            rtn += temp;
    }

    return rtn;
}

long long Planner::functionH(const Coordinate& current, const Coordinate& goal)
{
    long long rtn = abs(current.x - goal.x) + abs(current.y - goal.y);

    return rtn;
}

Quaternion Planner::robotMotion(const Quaternion& orientation,
    const Coordinate& current, const Coordinate& next, const nav_msgs::MapMetaData& map_info)
{
    EulerAngles ori_e = ToEulerAngles(orientation);

    double yaw = atan2(next.y - current.y, next.x - current.x);

    Quaternion next_ori;
    Quaternion temp = ToQuaternion({0, 0, yaw});

    next_ori.x = temp.x;
    next_ori.y = temp.y;
    next_ori.z = temp.z;
    next_ori.w = temp.w;

    return next_ori;
}

//==========================================================================//
// Main
//==========================================================================//
int main(int argc, char **argv)
{
    ros::init(argc, argv, "hybrid_a_star_planner");
    Planner planner;
    ros::Rate loop_rate(10);

    while(ros::ok())
    {
        planner.pathPublisher();

        ros::spinOnce();
		loop_rate.sleep();
	}

    return 0;
}