#include <vector>
#include <cmath>
#include <cstring>
#include <algorithm>

#include "ros/ros.h"
#include "ros/time.h"

#include "angle_conversion.h"

#include "geometry_msgs/PoseStamped.h"
#include "geometry_msgs/Pose.h"
#include "nav_msgs/Odometry.h"
#include "std_msgs/Bool.h"
#include "std_msgs/String.h"
#include "std_msgs/Float64.h"
#include "sensor_msgs/Image.h"
#include "nav_msgs/OccupancyGrid.h"
#include "nav_msgs/MapMetaData.h"

#include "zed_interfaces/Object.h"
#include "zed_interfaces/ObjectsStamped.h"

#include "sdhf/UserChanger.h"

using namespace std;

#define QUEUE_SIZE  1
#define SAFETY_DIST 1.0

bool cmp(pair<int, float>& a, pair<int, float>& b)
{
    if(a.second > b.second)
        return true;
    else
        return false;       
}

//==========================================================================//
// Class
//==========================================================================//
class HumanTracking
{
private:
    //structures
    struct User {
        float position[3];
        float velocity[3];
        int instance_id;
        bool track_status;
        bool follow_onoff;
    };

    struct LimitCoordinate {
        float x[2] = { 0, };
        float y[2] = { 0, };
    };
    
    //node handle
    ros::NodeHandle nh_;

    //msgs
    nav_msgs::Odometry jackal_odom_msg_;
    std_msgs::Float64 servo_msg_;

    geometry_msgs::PoseStamped simple_goal_msg_;

    //variables
    User user_;
    LimitCoordinate limit_coord_;
    vector<pair<int, float>> labels_;

    //PUBLISHER
    ros::Publisher simple_goal_pub_;
    ros::Publisher log_pub_;
    ros::Publisher servo_pub_;
    ros::Publisher labels_pub_;

    //SUBSCRIBER
    ros::Subscriber obj_info_sub_;
    ros::Subscriber odom_sub_;
    ros::Subscriber btn_follow_sub_;
    ros::Subscriber servo_sub_;
    ros::Subscriber map_sub_;

    //SERVICE SERVER
    ros::ServiceServer service_server_;

public:
    HumanTracking();
    ~HumanTracking();

    void objCallback(const zed_interfaces::ObjectsStamped::ConstPtr& obj_msg);
    void odomCallback(const nav_msgs::Odometry::ConstPtr& odom_msg);
    void btnFollowCallback(const std_msgs::Bool::ConstPtr& btn_msg);
    void feedbackCallback(const std_msgs::Float64::ConstPtr& servo_msg);
    void mapCallback(const nav_msgs::OccupancyGrid::ConstPtr& map_msg);

    bool userChanger(
        sdhf::UserChanger::Request& req, sdhf::UserChanger::Response& res);

    void targetPublish();
};

//==========================================================================//
// Class Constructor & Destructor
//==========================================================================//
HumanTracking::HumanTracking()
{
    //Subscriber
    obj_info_sub_ = nh_.subscribe(
        //"/zed2/zed_node/obj_det/objects",
        "/zed/zed_nodelet/obj_det/objects", QUEUE_SIZE,
        &HumanTracking::objCallback, this);
    odom_sub_ = nh_.subscribe(
        "/tracked_odom", QUEUE_SIZE, &HumanTracking::odomCallback, this);
    btn_follow_sub_ = nh_.subscribe(
        "/btn/follow", 2, &HumanTracking::btnFollowCallback, this);
    servo_sub_ = nh_.subscribe(
        "/servo_feedback", QUEUE_SIZE, &HumanTracking::feedbackCallback, this);
    map_sub_ = nh_.subscribe(
        "/map", QUEUE_SIZE, &HumanTracking::mapCallback, this);

    //Publisher
    simple_goal_pub_ = nh_.advertise<geometry_msgs::PoseStamped>(
        "/move_base_simple/goal", QUEUE_SIZE);
    log_pub_ = nh_.advertise<std_msgs::String>(
        "/log/human_tracking", QUEUE_SIZE);
    servo_pub_ = nh_.advertise<std_msgs::Float64>(
        "/cam_position_controller/command", QUEUE_SIZE);
    labels_pub_ = nh_.advertise<std_msgs::String>(
        "/log/labels", QUEUE_SIZE);

    //service server
    service_server_ = nh_.advertiseService(
        "user_changer", &HumanTracking::userChanger, this);

    //Variable
    user_.follow_onoff = false;
    user_.track_status = false;
    user_.instance_id = -1;

    simple_goal_msg_.header.frame_id = "map";
    simple_goal_msg_.pose.position.z = 0;

    labels_.clear();
}

HumanTracking::~HumanTracking(){}

//==========================================================================//
// Callback Function
//==========================================================================//
void HumanTracking::objCallback(
    const zed_interfaces::ObjectsStamped::ConstPtr& obj_msg)
{
    // If no objects, track_status is false
    user_.track_status = false;
    labels_.clear();

    // Search target data from id
    for (int i = 0; i < obj_msg->objects.size(); i++)
    {
        const zed_interfaces::Object& obj = obj_msg->objects[i];
        
        if(user_.track_status)
            break;

        labels_.push_back({obj.instance_id, obj.position[1]});

        // Saving Person/Object Information
        if(obj.label == "Person" && user_.instance_id == obj.instance_id)
        {
            labels_.clear();
            user_.track_status = true;
            //      1 ------- 2
            //     /.        /|
            //    0 ------- 3 |
            //    | .       | |
            //    | 5.......| 6
            //    |.        |/
            //    4 ------- 7
            //zed_interfaces/Keypoint3D[8] corners
            float bounding_box[8][3];
            memcpy(bounding_box, &(obj.bounding_box_3d.corners), sizeof(bounding_box));

            memset(user_.position, 0, sizeof(user_.position));
            for(int i = 0; i < 3; i++)
            {
                for(int j = 0; j < 8; j++)
                    user_.position[i] += bounding_box[j][i];

                user_.position[i] *= 0.125;
            }

            memcpy(user_.velocity, obj.velocity.begin(), sizeof(user_.velocity));
        }
    }

    if(!labels_.empty())
        sort(labels_.begin(), labels_.end(), cmp);
}

void HumanTracking::odomCallback(const nav_msgs::Odometry::ConstPtr& odom_msg)
{
    if(!odom_msg)
        return;

    geometry_msgs::Pose& jackal_pos = jackal_odom_msg_.pose.pose;
    const geometry_msgs::Pose& odom = odom_msg->pose.pose;

    jackal_pos.position = odom.position;
    jackal_pos.orientation = odom.orientation;
}

void HumanTracking::btnFollowCallback(const std_msgs::Bool::ConstPtr& btn_msg)
{
    if(!btn_msg)
        return;
    
    // Only when human is tracked, the button must work
    if(btn_msg->data)
    {
        if(user_.follow_onoff)
            user_.follow_onoff = false;
        else
            user_.follow_onoff = true;
    }
}

void HumanTracking::feedbackCallback(const std_msgs::Float64::ConstPtr& servo_msg)
{
    if(!servo_msg)
        return;

    servo_msg_ = *servo_msg;
}

void HumanTracking::mapCallback(const nav_msgs::OccupancyGrid::ConstPtr& map_msg)
{
    if(!map_msg)
        return;

    const nav_msgs::MapMetaData& map_info = map_msg->info;
    const geometry_msgs::Pose& pose = map_info.origin;
/*
    EulerAngles pose_eular = ToEulerAngles({
        pose.orientation.x,
        pose.orientation.y,
        pose.orientation.z,
        pose.orientation.w
    });
*/
    limit_coord_.x[0] = map_info.origin.position.x;
    limit_coord_.x[1] = map_info.origin.position.x + map_info.width * map_info.resolution;
    limit_coord_.y[0] = map_info.origin.position.y;
    limit_coord_.y[1] = map_info.origin.position.y + map_info.height * map_info.resolution;
}

//==========================================================================//
// Services Server Function
//==========================================================================//
bool HumanTracking::userChanger(
    sdhf::UserChanger::Request& req, sdhf::UserChanger::Response& res)
{
    user_.instance_id = req.label_id;
    user_.follow_onoff = false;
    return true;
}

//==========================================================================//
// Functions
//==========================================================================//

//==========================================================================//
// Publisher
//==========================================================================//
void HumanTracking::targetPublish()
{
    geometry_msgs::Pose& goal_pos = simple_goal_msg_.pose;
    const geometry_msgs::Pose& jackal_pos = jackal_odom_msg_.pose.pose;

    std_msgs::Float64 servo_msg;

    // If follow flag is off or track_status if false, jackal stops
    if(!user_.follow_onoff || !user_.track_status)
    {
        // Stop the movement now. in other words, goal is current jackal pos      
        simple_goal_msg_.pose = jackal_pos;

        if(!user_.track_status)
        {
            servo_msg.data = 0.;
            servo_pub_.publish(servo_msg);
        }
    }
    else
    {
        // Convert target coordinate
        EulerAngles jackal_eular = ToEulerAngles({
            jackal_pos.orientation.x,
            jackal_pos.orientation.y,
            jackal_pos.orientation.z,
            jackal_pos.orientation.w
        });
        double global_yaw = servo_msg_.data + jackal_eular.yaw;
        ANGLE2_RESTRICTION(global_yaw);

        float& x = user_.position[0];
        float& y = user_.position[1];
        double local_human_yaw = (double)atan2(y, x);
        double global_human_yaw = local_human_yaw + global_yaw;
        ANGLE2_RESTRICTION(global_human_yaw);

        double r = (double)sqrt(pow(x - SAFETY_DIST, 2) + pow(y, 2));

        // real position is not depend jackal center position
        goal_pos.position.x = jackal_pos.position.x + r * cos(global_human_yaw);
        goal_pos.position.y = jackal_pos.position.y + r * sin(global_human_yaw);

        double& gx = goal_pos.position.x;
        double& gy = goal_pos.position.y;

        if(gx < limit_coord_.x[0])
            gx = limit_coord_.x[0];
        else if(gx > limit_coord_.x[1])
            gx = limit_coord_.x[1];

        if(gy < limit_coord_.y[0])
            gy = limit_coord_.y[0];
        else if(gy > limit_coord_.y[1])
            gy = limit_coord_.y[1];
    
        float& vx = user_.velocity[0];
        float& vy = user_.velocity[1];
        double human_watch_yaw = (double)atan2(vy, vx) + jackal_eular.yaw;
        ANGLE2_RESTRICTION(human_watch_yaw);

        Quaternion goal_q = ToQuaternion({0, 0, jackal_eular.yaw});
        // human heading inference by detected human velocity using zed
        // problem : infered zed's velcoity of user isn't correct
        goal_pos.orientation.x = goal_q.x;
        goal_pos.orientation.y = goal_q.y;
        goal_pos.orientation.z = goal_q.z;
        goal_pos.orientation.w = goal_q.w;

        // publish msg only when user is detecting
        servo_msg.data = local_human_yaw + servo_msg_.data;
        ANGLE2_RESTRICTION(servo_msg.data);
        servo_pub_.publish(servo_msg);
    }
    
    static string logic_box[2] = {"false", "true"};
    static std_msgs::String log_msg;
    log_msg.data = ((("id: " + to_string(user_.instance_id))
                 + (", track: " + logic_box[user_.track_status]))
                 + (", onoff: " + logic_box[user_.follow_onoff]));

    simple_goal_msg_.header.stamp = ros::Time();
    // publish msg
    log_pub_.publish(log_msg);
    simple_goal_pub_.publish(simple_goal_msg_);

    if(!labels_.empty())
    {
        std_msgs::String labels_msg;
        labels_msg.data.clear();
        for(int i = 0; i < labels_.size(); i++)
            labels_msg.data += to_string(labels_[i].first) + ", ";
        labels_pub_.publish(labels_msg);
    }
}

//==========================================================================//
// Main
//==========================================================================//
int main(int argc, char **argv)
{
    ros::init(argc, argv, "human_tracking");
    HumanTracking ht;
    ros::Rate loop_rate(10);

	while(ros::ok())
    {
        ht.targetPublish();

        // multi thread spinner
        //ros::AsyncSpinner spinner(0);
        //spinner.start();

        // single thread spinner
        ros::spinOnce();
		loop_rate.sleep();
        //ros::spin();
	}

	return 0;
}
