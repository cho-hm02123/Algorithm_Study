# **Configuration Settings**

## **ZED**

1. Install ZED-SDK (version : 3.8.2)

   - [Link here](https://www.stereolabs.com/developers/release/)

   - Download *ZED SDK for Ubuntu 20*(Linux) / *ZED SDK for L4T 35.1 (Jetpack 5.0)*(Jetson)  
   _(The required CUDA, CuDNN, and TensorRT are automatically installed while installing the ZED SDK.)_

      - Follow [the install guides](https://www.stereolabs.com/docs/installation/linux/)

   - But if your cuda version is different, follow [the link](https://whiteglass.tistory.com/15)

      - *Must install CUDA 11.7*(Jetpack user install cuda-11.4)

      - Must **reboot** after installing CUDA

2. Started with ROS and ZED

   - **Caution** : Don't install *zed-ros-interfaces*.   
   Follow [the guides](https://www.stereolabs.com/docs/ros/)

3. How to fix ERROR

- Perhaps, it won't happend in the Jetpack (I did)

- Case 1 : Install CuDNN from [the link](https://developer.nvidia.com/rdp/cudnn-download)

   - version : 8.7.0.84-1+cuda11.8

   ```bash
   [ZED][ERROR] [Object Detection]  cuDNN library not found
   [ZED][ERROR] [ZED] [Object Detection]  CUDNN NOT FOUND
   ```
   
- Case 2 : Install TensorRT from [the link](https://developer.nvidia.com/nvidia-tensorrt-8x-download)

    - version : 8.5.2.2-1+cuda11.8

   ```bash
   [ZED][ERROR] [Object Detection]  TensorRT library not found
   [ZED][ERROR] [ZED] [Object Detection]  TRT NOT FOUND
   ```
   
4. If you need more information about ZED2 and API, refer to these links

   - ZED2 : [Link here](https://www.stereolabs.com/docs/get-started-with-zed/)

   - ZED2 API : [Link here](https://www.stereolabs.com/docs/api/index.html)

---

## **Jackal**

1. Install ROS-Noetic

   - [Link here](http://wiki.ros.org/noetic/Installation/Ubuntu)

   - Add the following code to .bashrc

   ```bash
   source /opt/ros/noetic/setup.bash
   source ~/catkin_ws/devel/setup.bash

   alias cm='cd ~/catkin_ws/ && catkin_make'
   ```

2. Jackal Tutorials

   - [Link here](https://www.clearpathrobotics.com/assets/guides/noetic/jackal/index.html)

   - **Caution** : Don't follow everything..

      - If you use noetic, download [jackal_robot](https://github.com/jackal/jackal_robot) and [jackal_desktop](https://github.com/jackal/jackal_desktop) on *~/catkin_ws/src* from github.

      ```bash
      $ git clone https://github.com/jackal/jackal_robot.git
      $ git clone https://github.com/jackal/jackal_desktop.git
      ```

      - And, other things install using 'sudo apt install'

   - UDEV Configuration

      - Create a rules file named *10-jackal*
   
      ```bash
      $ cd /etc/udev/rules.d
      $ sudo vim 10-jackal.rules
      ```

      - Write the following in *10-jackal.rules*
      
      ```bash
      SUBSYSTEM=="tty", ATTRS{idVendor}=="0483", ATTRS{idProduct}=="5740", SYMLINK="jackal", MODE="0666"
      ```

      - Reboot

---

## **RPLiDAR**

- Model : A1M8-R6

- Follow the [Fisrt Link](http://wiki.ros.org/rplidar) and [Second Link](https://github.com/robopeak/rplidar_ros/wiki)

---

## **SLAM : Cartographer-Ros**

   - **Caution** : Basically follow [the guide](https://google-cartographer-ros.readthedocs.io/en/latest/compilation.html), but not everything.

   - If you're using **catkin_make**, don't share work space with **catkin_make_isolated**.   
   Workspace must be distinguished like below.
   Want not to distinguish, switch the path : *catkin_ws_iso* -> *catkin_ws*

   ``` bash
   $ sudo apt-get install ninja-build libceres-dev libprotobuf-dev protobuf-compiler libprotoc-dev stow
   
   $ cd ~/catkin_ws_iso/src
   $ git clone https://github.com/googlecartographer/cartographer.git
   $ git clone https://github.com/googlecartographer/cartographer_ros.git
   $ cd ~/catkin_ws_iso

   $ src/cartographer/scripts/install_proto3.sh
   $ src/cartographer/scripts/install_abseil.sh
   $ cd /usr/local/stow
   $ sudo stow absl

   $ cd ~/catkin_ws_iso
   $ rosdep install --from-paths src --ignore-src -r -y
   $ catkin_make_isolated --install --use-ninja

   $ source ~/catkin_ws_iso/install_isolated/setup.bash
   ```

   - If you got the error of python version, following next

      1. Check the python version
      
      ```bash
      $ python -V
      ```

      2. Check the python path of installed
   
      ```bash
      $ ls /usr/bin/ | grep python
      ```

      3. Try to switch the default of python 

      ```bash
      $ sudo update-alternatives --config python
      update-alternatives: error: no alternatives for python
      ```

      4. If you got the update-alternatives error, enter the command of according to the rules : 

      ```bash
      $ sudo update-alternatives --install [python path]/python python [python path]/python[version] [number]
      ```

      - Examples

      ```bash      
      $ sudo update-alternatives --install /usr/bin/python python /usr/bin/python2.7 1
      $ sudo update-alternatives --install /usr/bin/python python /usr/bin/python3.6 2
      ```

      5. Try again

      ```bash
      $ sudo update-alternatives --config python
      ```

   - Add the following code to .bashrc 

   ```bash
   & source ~/catkin_ws_iso/install_isolated/setup.bash
   ```

   - Test
   
   ```bash
   $ wget -P ~/Downloads https://storage.googleapis.com/cartographer-public-data/bags/backpack_2d/cartographer_paper_deutsches_museum.bag
   $ roslaunch cartographer_ros demo_backpack_2d.launch bag_filename:=${HOME}/Downloads/cartographer_paper_deutsches_museum.bag
   ```

   sudo apt-get install ros-noetic-map-server

---

## **ROS Move Base**

- Used Global Planner and Base Local Planner.

```bash
$ sudo apt-get install ros-noetic-global-planner ros-noetic-base-local-planner
```

---

## **Dynamixel Library Setup**
 
- If you won't be using ROS, then follow [the reference using cpp](https://emanual.robotis.com/docs/en/software/dynamixel/dynamixel_sdk/library_setup/cpp_linux/#cpp-linux).

   - This reference used to test dynamixel. And, you see the example codes.

- However, if you don't use it, you have to install the Dynamixel SDK for ROS.
```bash
$ sudo apt-get install ros-noetic-dynamixel-sdk
```

- UDEV Configuration

   - Create a rules file named *-dynamixel-u2d2*

   ```bash
   $ cd /etc/udev/rules.d
   $ sudo vim 10-dynamixel-u2d2.rules
   ```

   - Write the following in *10-dynamixel-u2d2.rules*

      - "idVendor" and "idProduct" may differ depending on the product.
   
   ```bash
   SUBSYSTEM=="tty", ATTRS{idVendor}=="0403", ATTRS{idProduct}=="6014", SYMLINK="dynamixel-u2d2", MODE="0666"
   ```