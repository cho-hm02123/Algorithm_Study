# **Project Jackal**

## **Features**

**PC** : Jetson AGX Xavior - Jetpack 5.0.2 / Ubuntu 20.04

**PLATFORM** : Jackal without NUC(Instead, use AGX)

**MAIN SENSOR** : ZED2

---

## **Configuration Settings**

### **Install VScode**

- [Link here](https://code.visualstudio.com/docs/setup/linux)

### **JetPack**

- Install *NVIDIA SDK Manager* from [here](https://developer.nvidia.com/drive/sdk-manager)

- *JetPack 5.0.2* == Ubuntu 20.04

- Enter the recovery mode

   - Press the both to fisrt and second buttons together

- If SDK components installer didn't work, skip the installer.   
When I did it, started the installation without changing the settings, then it worked.

- When *JetPack* is first installed, the cooling fan may not work.   
Refer to the [post](https://makejarvis.tistory.com/89) and [reference](https://docs.nvidia.com/jetson/archives/r34.1/DeveloperGuide/text/SD/PlatformPowerAndPerformance/JetsonXavierNxSeriesAndJetsonAgxXavierSeries.html#nvfancontrol)

   - To set the power mode

      - Reboot required for settings to take effect

      ```bash
      $ sudo nvpmodel -m 0
      ```

   - To set the fan mode to cool

      - Open the fan control configuration

      ```bash
      $ sudo vim /etc/nvfancontrol.conf
      ```

      - Modify **FAN_DEFAULT_PROFILE** to either quiet to cool

      - Restart the fan control demon

      ```bash
      $ sudo systemctl stop nvfancontrol
      $ sudo rm /var/lib/nvfancontrol/status
      $ sudo systemctl start nvfancontrol
      ```

### ROS-Noetic

   - Install ROS-Noetic

      - [Link here](http://wiki.ros.org/noetic/Installation/Ubuntu)

      - Make catkin workspace

      ```bash
      $ mkdir -p ~/catkin_ws/src
      $ cd ~/catkin_ws/
      $ source /opt/ros/noetic/setup.bash
      $ catkin_make
      ```

      - Add the following code to .bashrc

      ```bash
      source /opt/ros/noetic/setup.bash
      source ~/catkin_ws/devel/setup.bash

      alias cm='cd ~/catkin_ws/ && catkin_make'
      ```

### **ZED**

1. Install ZED-SDK (version : 3.8.2)

   - [Link here](https://www.stereolabs.com/developers/release/)

   - Download *ZED SDK for Ubuntu 20*(Linux) / *ZED SDK for L4T 35.1 (Jetpack 5.0)*(Jetson)  
   _(The required CUDA, CuDNN, and TensorRT are automatically installed while installing the ZED SDK.)_

      - Follow [the install guides](https://www.stereolabs.com/docs/installation/linux/)

      - Common

      ```bash
      $ sudo apt install zstd
      $ cd ~/Downloads
      ```

      - *Ubuntu 20.04*

      ```bash
      $ chmod +x ZED_SDK_Ubuntu20_cuda11.7_v3.8.2.zstd.run
      $ ./ZED_SDK_Ubuntu20_cuda11.7_v3.8.2.zstd.run -- silent
      ```

      - *JetPack 5.0.2*

      ```bash
      $ chmod +x ZED_SDK_Tegra_L4T35.1_v3.8.2.zstd.run
      $ ./ZED_SDK_Tegra_L4T35.1_v3.8.2.zstd.run -- silent
      ```

   - If your cuda version is higher than required version, it runs well

      - If you want to change your cuda version, follow [the link](https://whiteglass.tistory.com/15)

      - install *CUDA 11.7*(Jetpack user install cuda-11.4)

      - Must **reboot** after installing CUDA

2. Started with ROS and ZED

   - **Caution** : Don't install *zed-ros-interfaces*.   
   Follow [the guides](https://www.stereolabs.com/docs/ros/)

3. To test zed2 object-detection API

   - If this program works fine, zed2 sdk installation is complete.

   - Terminal 1

   ```bash
   $ roslaunch zed_display_rviz display_zed2.launch
   ```

   - Terminal 2

   ```bash
   $ rosservice call /zed2/zed_node/start_object_detection "{model: 0, confidence: 0.0, max_range: 0.0, tracking: true, sk_body_fitting: false,
      mc_people: true, mc_vehicles: false, mc_bag: false, mc_animal: false, mc_electronics: false,
      mc_fruit_vegetable: false, mc_sport: false}"
   ```

4. How to fix ERROR

- Perhaps, it won't happened in the Jetpack (when I did)

- Case 1 : Install CuDNN from [the link](https://developer.nvidia.com/rdp/cudnn-download)

   - version : 8.7.0.84-1+cuda11.8

   ```bash
   [ZED][ERROR] [Object Detection]  cuDNN library not found
   [ZED][ERROR] [ZED] [Object Detection]  CUDNN NOT FOUND
   ```

- Case 2 : Install TensorRT from [the link](https://developer.nvidia.com/nvidia-tensorrt-8x-download)

    - version : 8.5.2.2-1+cuda11.8

   ```bash
   [ZED][ERROR] [Object Detection]  TensorRT library not found
   [ZED][ERROR] [ZED] [Object Detection]  TRT NOT FOUND
   ```
   
5. If you need more information about ZED2 and API, refer to these links

   - ZED2 : [Link here](https://www.stereolabs.com/docs/get-started-with-zed/)

   - ZED2 API : [Link here](https://www.stereolabs.com/docs/api/index.html)

### **Jackal**

- Jackal Tutorials

   - [Link here](https://www.clearpathrobotics.com/assets/guides/noetic/jackal/index.html)

   - Install Jackal Packages

      - Installing a library to prevent catkin_make and roslaunch error

      ```bash
      $ sudo apt-get install ros-noetic-rosserial-server ros-noetic-rosserial-python ros-noetic-nmea-msgs ros-noetic-nmea-navsat-driver ros-noetic-imu-filter-madgwick
      ```

      ```bash
      $ sudo apt-get install ros-noetic-jackal-*
      ```

      - Download [jackal_robot](https://github.com/jackal/jackal_robot) and [jackal_desktop](https://github.com/jackal/jackal_desktop) on *~/catkin_ws/src* from github.

      ```bash
      $ cd ~/catkin_ws/src
      $ git clone https://github.com/jackal/jackal_robot.git
      $ git clone https://github.com/jackal/jackal_desktop.git
      $ cm
      ```

   - UDEV Configuration

      - Create a rules file named *10-jackal*
   
      ```bash
      $ cd /etc/udev/rules.d
      $ sudo vim 10-jackal.rules
      ```

      - Write the following in *10-jackal.rules*
      
      ```bash
      SUBSYSTEM=="tty", ATTRS{idVendor}=="0483", ATTRS{idProduct}=="5740", SYMLINK="jackal", MODE="0666"
      ```

      - Reboot
   
- To test the Jackal

   - If you want jackal simulation, execute the following code together

   ```bash
   $ roslaunch jackal_viz view_robot.launch
   ```

   - Won't, execute only the following code 

   ```bash
   $ roslaunch jackal_base base.launch
   ```

   - Ros-Topic publish

      - Change the value set of 0.0

      ```bash
      $ rostopic pub /cmd_vel geometry_msgs/Twist "linear:
        x: 0.2
        y: 0.0
        z: 0.0
      angular:
        x: 0.0
        y: 0.0
        z: 0.0"
      ```

   - If you move, you succeed. Or check the battery and try again.
---

## Sensor Data Processing

   - laser_geometry  (LaserScan -> PointCloud) :
   
   ```bash
   $ sudo apt-get install ros-noetic-laser-geometry
   ```

   - Point Cloud Library : PCL  (PointCloud -> Voxeled Point Cloud)
   
   ```bash
   $ sudo apt-get install ros-noetic-pcl-ros ros-noetic-pcl-conversions ros-noetic-pcl-msgs
   ```

## Path Planning : DWA

   - Must download the following path:'~/'

   ```bash
   $ cd ~
   $ git clone https://github.com/AtsushiSakai/PythonRobotics.git
   ```
 
 ---
 
 ## SLAM : Cartographer-Ros

   - **Caution** : Basically follow [the guide](https://google-cartographer-ros.readthedocs.io/en/latest/compilation.html), but not everything.

   - If you're using **catkin_make**, don't share work space with **catkin_make_isolated**.   
   Workspace must be distinguished like below.
   Want not to distinguish, switch the path : *catkin_ws_iso* -> *catkin_ws*

   ``` bash
   $ sudo apt-get install ninja-build libceres-dev libprotobuf-dev protobuf-compiler libprotoc-dev stow -y
   
   $ mkdir -p ~/catkin_ws_iso/src
   $ cd ~/catkin_ws_iso/src/
   $ git clone https://github.com/googlecartographer/cartographer.git
   $ git clone https://github.com/googlecartographer/cartographer_ros.git
   $ cd ~/catkin_ws_iso/

   $ src/cartographer/scripts/install_proto3.sh
   $ src/cartographer/scripts/install_abseil.sh
   $ cd /usr/local/stow/
   $ sudo stow absl

   $ cd ~/catkin_ws_iso/
   $ rosdep install --from-paths src --ignore-src -r -y
   $ catkin_make_isolated --install --use-ninja

   $ source ~/catkin_ws_iso/install_isolated/setup.bash
   ```

   - Library unknown if needed, might it need...?

   ```bash
   sudo apt-get install ros-noetic-map-server ros-noetic-move-base ros-noetic-carrot-planner ros-noetic-global-planner
   ```

   - If you got the error of python version, following next

      1. Check the python version
      
      ```bash
      $ python -V
      ```

      2. Check the python path of installed
   
      ```bash
      $ ls /usr/bin/ | grep python
      ```

      3. Try to switch the default of python 

      ```bash
      $ sudo update-alternatives --config python
      update-alternatives: error: no alternatives for python
      ```

      4. If you got the update-alternatives error, enter the command of according to the rules : 

      ```bash
      $ sudo update-alternatives --install [python path]/python python [python path]/python[version] [number]
      ```

      - Examples

      ```bash      
      $ sudo update-alternatives --install /usr/bin/python python /usr/bin/python2.7 1
      $ sudo update-alternatives --install /usr/bin/python python /usr/bin/python3.6 2
      ```

      5. Try again

      ```bash
      $ sudo update-alternatives --config python
      ```

   - Add the following code to .bashrc 

   ```bash
   source ~/catkin_ws_iso/install_isolated/setup.bash
   ```

   - Test
   
   ```bash
   $ wget -P ~/Downloads https://storage.googleapis.com/cartographer-public-data/bags/backpack_2d/cartographer_paper_deutsches_museum.bag
   $ roslaunch cartographer_ros demo_backpack_2d.launch bag_filename:=${HOME}/Downloads/cartographer_paper_deutsches_museum.bag
   ```

 ---

## How to Run?

### 1. Path Planning(DWA)
   
   ```bash
   $ roslaunch xproject dwa.launch
   ```

### 3. Path Planning(DWA) with SLAM(Cartographer) about Simulation

   ```bash
   $ roslaunch xproject slam_sim.launch once_arg:=true
   ```

### 3. Path Planning(DWA) with SLAM(Cartographer) about Test(Real World)

   - Terminal 1

      - Connect to the jackal via SSH.

      ```bash
      $ ssh {jackal_id}@{jackal_ip}
      ```

      - Configure *ROS_IP* and *ROS_HOSTNAME*, then run the launch file

      ```bash
      $ export ROS_IP={jackal_ip}
      $ export ROS_HOSTNAME=$ROS_IP

      $ roslaunch xproject slam.launch once_arg:=true
      ```

   - Terminal 2

      - Configure *ROS_MASTER_URI* and *ROS_HOSTNAME*, then run a rviz via launch file

      ```bash
      $ export ROS_MASTER_URI=http://{jackal_ip}:11311
      $ export ROS_HOSTNAME={hostpc_ip}

      $ roslaunch xproject rviz.launch
      ```

 ---