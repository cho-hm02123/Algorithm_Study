#include <cmath>
#include <string>

#include "ros/ros.h"
#include "ros/time.h"

#include "geometry_msgs/PoseStamped.h"
#include "nav_msgs/Odometry.h"

using namespace std;

class TransformPoseToOdom {
private:
    ros::NodeHandle nh;

    geometry_msgs::PoseStamped pose_msg_;
    nav_msgs::Odometry odom_msg_;

    struct Quaternion {
        double x, y, z, w;
    };

    struct EulerAngles {
        double roll, pitch, yaw;
    };

    double theta_;
    ros::Time time_;
	ros::Duration sec_;

    ros::Subscriber pose_sub_;
    ros::Publisher odom_pub_;

public:
    TransformPoseToOdom()
    {
        pose_sub_ = nh.subscribe("/tracked_pose", 1, &TransformPoseToOdom::poseCallback,this);
        odom_pub_ = nh.advertise<nav_msgs::Odometry>("/cmd_pose", 1);

        theta_ = 0;
        time_ = ros::Time::now();
    }

    ~TransformPoseToOdom()
    {
    }

    EulerAngles ToEulerAngles(Quaternion q) {
        EulerAngles angles;

        // roll (x-axis rotation)
        double sinr_cosp = 2 * (q.w * q.x + q.y * q.z);
        double cosr_cosp = 1 - 2 * (q.x * q.x + q.y * q.y);
        angles.roll = std::atan2(sinr_cosp, cosr_cosp);

        // pitch (y-axis rotation)
        double sinp = std::sqrt(1 + 2 * (q.w * q.y - q.x * q.z));
        double cosp = std::sqrt(1 - 2 * (q.w * q.y - q.x * q.z));
        angles.pitch = 2 * std::atan2(sinp, cosp) - M_PI / 2;

        // yaw (z-axis rotation)
        double siny_cosp = 2 * (q.w * q.z + q.x * q.y);
        double cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z);
        angles.yaw = std::atan2(siny_cosp, cosy_cosp);

        return angles;
    }

    void poseCallback(const geometry_msgs::PoseStamped::ConstPtr& pose_msg);
};