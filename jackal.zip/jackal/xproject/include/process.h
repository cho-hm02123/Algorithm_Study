#include <vector>
#include <cmath>
#include <vector>
#include <string>

#include "ros/ros.h"
#include "ros/time.h"

#include "angles/angles.h"

#include "zed_interfaces/Object.h"
#include "zed_interfaces/ObjectsStamped.h"

#include "geometry_msgs/Twist.h"
#include "geometry_msgs/PoseStamped.h"
#include "nav_msgs/Odometry.h"

#include "sensor_msgs/LaserScan.h"
#include "sensor_msgs/PointCloud.h"
#include "tf/transform_listener.h"
#include "laser_geometry/laser_geometry.h"

#include "pcl_ros/point_cloud.h"
#include "pcl/point_types.h"
#include "pcl/point_cloud.h"
#include "pcl_conversions/pcl_conversions.h"
#include "pcl/filters/voxel_grid.h"

#include "xproject/Xproject.h"

using namespace std;

class test_class{
private:
    //node handle
    ros::NodeHandle nh;

    //msgs
    xproject::Xproject project_msg_;
    //geometry_msgs::Twist cmd_msg_;
    //geometry_msgs::Twist target_velocity_msg_;
    geometry_msgs::PoseStamped simple_goal_msg_;
    nav_msgs::Odometry tracked_pose_msg_;

    laser_geometry::LaserProjection projector_;
    //tf::TransformListener listener_;
    sensor_msgs::PointCloud msgCloud;

    //variables
    float target_center_[3] = {0};
    float target_center_dist_;
    float target_atan_;
    float target_atan2_;
    bool callback_status_;
    bool check_callback_;
    bool cancel_goal_;
    uint32_t shape;
    ros::Time start_;
	ros::Time end_;
	ros::Duration sec_;

    //structures
    struct Quaternion {
        double x, y, z, w;
    };

    struct EulerAngles {
        double roll, pitch, yaw;
    };

    struct User {
        int label_id;
        bool track_status;
    };
    
    EulerAngles angle;
    User user;
    //float cx, cy;

    //vectors
    vector<zed_interfaces::Object> person_list_;
    vector<zed_interfaces::Object> obj_list_;
    //vector<boost::array<float, 3>> person_cp_;
    vector< vector<float> > person_cp_;
    vector< vector<float> > obj_cp_;
    vector<float> temp_center_;
    vector<float> person_dist_;
    vector<float> obj_dist_;
    
    //PUBLISHER
    ros::Publisher target_info_pub_;
    //ros::Publisher cmd_ctr_pub_;
    //ros::Publisher target_velocity_pub_;
    ros::Publisher voxelization_pc_pub;
    ros::Publisher simple_goal_pub_;

    //SUBSCRIBER
    ros::Subscriber obj_inf_sub;
    ros::Subscriber odom_sub;
    ros::Subscriber laserscan_sub;

    
public:
    test_class(){
        initSetup();
    }

    ~test_class(){
        person_list_.clear();
        obj_list_.clear();
        person_cp_.clear();
        obj_cp_.clear();
        person_dist_.clear();
        obj_dist_.clear();
        temp_center_.clear();
    }
    
    void initSetup()
    {
        //Subscriber
        obj_inf_sub = nh.subscribe("/zed2/zed_node/obj_det/objects",1,&test_class::objCallback,this);
        odom_sub = nh.subscribe("/cmd_pose",1,&test_class::odomCallback,this);
        laserscan_sub = nh.subscribe("/zed/scan",1,&test_class::laserscanCallback,this);

        //Publisher
        target_info_pub_ = nh.advertise<xproject::Xproject>("Xproject",1);
        //cmd_ctr_pub_ = nh.advertise<geometry_msgs::Twist>("/cmd_vel",1);
        //target_velocity_pub_ = nh.advertise<geometry_msgs::Twist>("/target_velocity",1);
        voxelization_pc_pub = nh.advertise<sensor_msgs::PointCloud2>("/voxel_pointcloud",1);
        simple_goal_pub_ = nh.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal",1);

        //Variable
        target_center_dist_ = 0;
        target_atan_ = 0;
        target_atan2_ = 0;
        callback_status_ = false;
        check_callback_ = false;
        cancel_goal_ = false;
        //cx = 0;
        //cy = 0;

        user.track_status = false;
        user.label_id = -1;
    }
    

    // CALLBACK

    void objCallback(const zed_interfaces::ObjectsStamped::ConstPtr& obj_msg)
    {  
        callback_status_ = true;

        // clear vector memory(size, capacity)
        person_list_.clear();
        vector<zed_interfaces::Object>().swap(person_list_);
        obj_list_.clear();
        vector<zed_interfaces::Object>().swap(obj_list_);
        person_cp_.clear();
        //vector<boost::array<float, 3>>().swap(person_cp_);
        vector<vector<float>>().swap(person_cp_);
        obj_cp_.clear();
        vector<vector<float>>().swap(obj_cp_);
        person_dist_.clear();
        vector<float>().swap(person_dist_);
        obj_dist_.clear();
        vector<float>().swap(obj_dist_);

        float temp_dist = 0;

        if(!(obj_msg->objects.size() > 0))
        {  
            user.track_status = false;
            ROS_INFO_STREAM("object not found");
            return;
        }
        else
            ROS_INFO_STREAM("id: " << user.label_id << " status: " << (user.track_status ? "true" : "false"));

        for (int i = 0; i < obj_msg->objects.size(); i++)
        {
            const zed_interfaces::Object& _obj = obj_msg->objects[i];
            
            if (_obj.label_id == -1)
                continue;

            //Saving Person/Object Information
            if(!user.track_status && (_obj.label == "Person"))
            {
                if(user.label_id == _obj.label_id)
                    user.track_status = true;
                else if(user.label_id == -1)
                {
                    user.track_status = true;
                    user.label_id = _obj.label_id;
                }
            }

            if(user.track_status && (user.label_id == _obj.label_id))
            {
                person_list_.push_back(_obj);
                
                cal_center_point(_obj);
                person_cp_.push_back(temp_center_);

                temp_dist = sqrt(pow(temp_center_[0],2) + pow(temp_center_[1],2) + pow(temp_center_[2],2));
                person_dist_.push_back(temp_dist);
            }
            else
            {
                obj_list_.push_back(_obj);

                cal_center_point(_obj);
                obj_cp_.push_back(temp_center_);

                temp_dist = sqrt(pow(temp_center_[0],2) + pow(temp_center_[1],2) + pow(temp_center_[2],2));
                obj_dist_.push_back(temp_dist);
            }
        }
    }

    void odomCallback(const nav_msgs::Odometry::ConstPtr& odom_msg)
    {
        geometry_msgs::Pose& _t_pose = tracked_pose_msg_.pose.pose;
        geometry_msgs::Point& _t_pos = _t_pose.position;
        geometry_msgs::Quaternion& _t_ori = _t_pose.orientation;

        const geometry_msgs::Pose& _pose = odom_msg->pose.pose;
        const geometry_msgs::Point& _pos = _pose.position;
        const geometry_msgs::Quaternion& _ori = _pose.orientation;

        _t_pos.x = _pos.x;
        _t_pos.y = _pos.y;
        _t_pos.z = _pos.z;

        _t_ori.x = _ori.x;
        _t_ori.y = _ori.y;
        _t_ori.z = _ori.z;
        _t_ori.w = _ori.w;
    }

    void laserscanCallback(const sensor_msgs::LaserScan::ConstPtr& scan_in){
        
        //sensor_msgs::LaserScan ---convert to---> sensor_msgs::PointCloud
        laser_geometry::LaserProjection projector_;
        projector_.projectLaser(*scan_in, msgCloud);

        /*
        // another method to projection
        if(!listener_.waitForTransform(scan_in->header.frame_id, "/base_link", scan_in->header.stamp + ros::Duration().fromSec(scan_in->ranges.size()*scan_in->time_increment), ros::Duration(1.0))){
            return;
        }
        projector_.transformLaserScanToPointCloud("/base_link",*scan_in, msgCloud,listener_);
        */
    }

    //Publisher
    void pointcloud_voxel_pub(){
        // converted LaserScan information ---contain to---> sensor_msgs::PointCloud
        pcl::PointCloud<pcl::PointXYZ> inputCloud;
		inputCloud.width = msgCloud.points.size();
		inputCloud.height = 1;
		inputCloud.points.resize(inputCloud.width * inputCloud.height);
		for (int i = 0; i < msgCloud.points.size(); i++)
		{
			inputCloud.points[i].x = msgCloud.points[i].x;
			inputCloud.points[i].y = msgCloud.points[i].y;
			inputCloud.points[i].z = 0;
		}

        // filter start
		pcl::PointCloud<pcl::PointXYZ> voxelCloud;

		//Voxelization 
		pcl::VoxelGrid<pcl::PointXYZ> vox;
		vox.setInputCloud(inputCloud.makeShared());
		vox.setLeafSize(0.25f, 0.25f, 0.25f); // set Voxel Grid Size value 1 = 1(m)
		vox.filter(voxelCloud);

        //contains voxel information in pointcloud2.
        sensor_msgs::PointCloud2 voxeledOutput;
		pcl::toROSMsg(voxelCloud, voxeledOutput);

        voxelization_pc_pub.publish(voxeledOutput);
    }

    void person_info_pub(){
        if(person_list_.size() != 0){
            target_center_dist_ = person_dist_[0];
            target_atan2_ = atan2(person_cp_[0][1],person_cp_[0][0])*180/3.141592;

            project_msg_.distance = target_center_dist_;
            project_msg_.angle = target_atan2_;
            project_msg_.pos_x = person_cp_[0][0];
            project_msg_.pos_y = person_cp_[0][1];
            target_info_pub_.publish(project_msg_);
        }
    }

    void goal_pub()
    {
        if(user.track_status && (person_list_.size() != 0))
        {
            cancel_goal_ = false;

            geometry_msgs::Pose& _tracked_pose = tracked_pose_msg_.pose.pose;
            geometry_msgs::Point& _tracked_pos = _tracked_pose.position;
            geometry_msgs::Quaternion& _tracked_ori = _tracked_pose.orientation;

            double x = person_cp_[0][0], 
                   y = person_cp_[0][1];
            double r = sqrt(pow(x, 2) + pow(y, 2));

            Quaternion t_q =
            {
                _tracked_ori.x,
                _tracked_ori.y,
                _tracked_ori.z,
                _tracked_ori.w
            };
            EulerAngles t_e = ToEulerAngles(t_q);

            EulerAngles e = 
            {
                0,
                0,
                atan2(y, x) + t_e.yaw
            };

            if(e.yaw > M_PI)
                e.yaw -= 2 * M_PI;
            else if(e.yaw < -M_PI)
                e.yaw += 2 * M_PI;
            
            Quaternion q = ToQuaternion(e);

            simple_goal_msg_.header.frame_id = "map";//"base_link";
            simple_goal_msg_.header.stamp = ros::Time::now();

            geometry_msgs::Pose& _pose = simple_goal_msg_.pose;
            geometry_msgs::Point& _pos = _pose.position;
            geometry_msgs::Quaternion& _ori = _pose.orientation;

            if(r > 1.25)
            {
                _pos.x = _tracked_pos.x + (r - 1.0) * cos(e.yaw);
                _pos.y = _tracked_pos.y + (r - 1.0) * sin(e.yaw);
            }
            else
            {
                _pos.x = _tracked_pos.x + 0.25 * cos(e.yaw); //+ r * cos(e.yaw);
                _pos.y = _tracked_pos.y + 0.25 * sin(e.yaw); //+ r * sin(e.yaw);
            }
            _pos.z = 0; //person_cp_[0][2];

            _ori.x = q.x;
            _ori.y = q.y;
            _ori.z = q.z;
            _ori.w = q.w;

            simple_goal_pub_.publish(simple_goal_msg_);
        }
        else if(!cancel_goal_)
        {
            cancel_goal_ = true;

            geometry_msgs::Pose& _tracked_pose = tracked_pose_msg_.pose.pose;
            geometry_msgs::Pose& _pose = simple_goal_msg_.pose;

            simple_goal_msg_.header.frame_id = "map";//"base_link";
            simple_goal_msg_.header.stamp = ros::Time::now();
            _pose = _tracked_pose;

            simple_goal_pub_.publish(simple_goal_msg_);
        }
    }

    // Functions
    void cal_center_point(zed_interfaces::Object msg){
        temp_center_.clear();
        vector<float>().swap(temp_center_);
        
        float point_ = 0;
        float obj_[8][3] = {0};
        memcpy(obj_, &(msg.bounding_box_3d.corners), 24 * sizeof(float));

        for(int i = 0; i < 3; i++){
            //point_ = (obj_[0][i] + obj_[3][i] + obj_[4][i] + obj_[7][i]) * 0.25;
            point_ = (obj_[4][i] + obj_[5][i] + obj_[6][i] + obj_[7][i]) * 0.25;
            temp_center_.push_back(point_);
        }
    }

    EulerAngles ToEulerAngles(Quaternion q) {
        EulerAngles angles;

        // roll (x-axis rotation)
        double sinr_cosp = 2 * (q.w * q.x + q.y * q.z);
        double cosr_cosp = 1 - 2 * (q.x * q.x + q.y * q.y);
        angles.roll = std::atan2(sinr_cosp, cosr_cosp);

        // pitch (y-axis rotation)
        double sinp = std::sqrt(1 + 2 * (q.w * q.y - q.x * q.z));
        double cosp = std::sqrt(1 - 2 * (q.w * q.y - q.x * q.z));
        angles.pitch = 2 * std::atan2(sinp, cosp) - M_PI / 2;

        // yaw (z-axis rotation)
        double siny_cosp = 2 * (q.w * q.z + q.x * q.y);
        double cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z);
        angles.yaw = std::atan2(siny_cosp, cosy_cosp);

        return angles;
    }

    Quaternion ToQuaternion(EulerAngles e)
    {
        Quaternion q;

        double cr = cos(e.roll * 0.5);
        double sr = sin(e.roll * 0.5);
        double cp = cos(e.pitch * 0.5);
        double sp = sin(e.pitch * 0.5);
        double cy = cos(e.yaw * 0.5);
        double sy = sin(e.yaw * 0.5);

        q.w = cr * cp * cy + sr * sp * sy;
        q.x = sr * cp * cy - cr * sp * sy;
        q.y = cr * sp * cy + sr * cp * sy;
        q.z = cr * cp * sy - sr * sp * cy;

        return q;
    }
    
    void process();
};