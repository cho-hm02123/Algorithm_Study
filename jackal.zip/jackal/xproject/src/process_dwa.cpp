#include "process.h"

void test_class::process(){
    // match zed carmera sub topic
    if(!check_callback_){
        ros::Time::init();
		start_ = ros::Time::now();
        check_callback_ = true;
    }
    else if(!callback_status_){
        end_ = ros::Time::now();
		sec_ = end_ - start_;
        if(sec_.toSec() > 2.0)
		    obj_inf_sub = nh.subscribe("/zed/zed_nodelet/obj_det/objects",1,&test_class::objCallback,this);
    }

    //publish function

    // the smallest ID value person's x,y,distance,anngle 
    person_info_pub();
    //laserscan -> pointcloud -> voxelization
    pointcloud_voxel_pub();
    goal_pub();
}

int main(int argc, char **argv){
    ros::init(argc, argv, "process_dwa");
    test_class test;
    ros::Rate loop_rate(5);
	while(ros::ok()) {
		ros::spinOnce();
		test.process();
		//test.rviz();
		loop_rate.sleep();
	}

	return 0;
}
