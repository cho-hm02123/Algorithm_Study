#include "transform_pose_to_odom.h"

void TransformPoseToOdom::poseCallback(const geometry_msgs::PoseStamped::ConstPtr& pose_msg)
{
    /*
    ros::Time t = ros::Time::now();
    sec_ = t - time_;
    time_ = t;
    
    double dx = pose_msg->pose.position.x - odom_msg_.pose.pose.position.x,
           dy = pose_msg->pose.position.y - odom_msg_.pose.pose.position.y;

    Quaternion q = {pose_msg->pose.orientation.x,
                    pose_msg->pose.orientation.y,
                    pose_msg->pose.orientation.z,
                    pose_msg->pose.orientation.w};

    EulerAngles e = ToEulerAngles(q);
    
    double th = e.yaw;
    double dth = th - theta_;

    theta_ = th;

    double v = sqrt(pow(dx, 2) + pow(dy, 2)) / sec_.toSec(),
           w = dth / sec_.toSec();

    if(cos(th) * cos(atan2(dy, dx)) < 0)
        v = (-1) * v;
    */
    //ROS_INFO_STREAM(sec_.toSec() << ' ' << v << ' ' << w);

    odom_msg_.pose.pose.position.x = pose_msg->pose.position.x;
    odom_msg_.pose.pose.position.y = pose_msg->pose.position.y;
    odom_msg_.pose.pose.position.z = pose_msg->pose.position.z;

    odom_msg_.pose.pose.orientation.x = pose_msg->pose.orientation.x;
    odom_msg_.pose.pose.orientation.y = pose_msg->pose.orientation.y;
    odom_msg_.pose.pose.orientation.z = pose_msg->pose.orientation.z;
    odom_msg_.pose.pose.orientation.w = pose_msg->pose.orientation.w;

    //odom_msg_.twist.twist.linear.x = v;
    //odom_msg_.twist.twist.angular.z = w;

    odom_pub_.publish(odom_msg_);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "transform_pose_to_odom");
    TransformPoseToOdom tpto;
    ros::Rate loop_rate(200);

	while(ros::ok())
    {
		ros::spinOnce();
		loop_rate.sleep();
	}

	return 0;
}