import time
from math import atan2, sqrt, pi, degrees, asin
import rospy
from geometry_msgs.msg import Twist, Point, Pose, Quaternion, PoseStamped
from nav_msgs.msg import Path, Odometry
from tf.transformations import euler_from_quaternion, quaternion_from_euler
from time import sleep

import numpy as np
import control, os, signal, sys, math

T = 0.01
K1, K2 = 0.1, 0.2
POINT = 2
# ========================= #

g_pos = np.array([0.0, 0.0, 0.0, 0.0, 0.0])
g_tar = g_pos
g_goal = np.zeros(2)
# ========================= #
def callback(path):
    global g_tar, g_pos, g_goal
    tr = path.poses
    '''
    if tr:
        cur = tr[-1].pose
        g_tar = np.array([cur.position.x,
                cur.position.y,
                cur.position.z,
                cur.orientation.x,
                cur.orientation.y])
    else:
        g_tar = g_pos
    '''
    g_tar = []

    if not tr:
        g_tar = g_pos
        return

    for t in tr:
        p = t.pose
        if len(g_tar):
            g_tar = np.vstack((g_tar, [ p.position.x,
                                    p.position.y,
                                    p.position.z,
                                    p.orientation.x,
                                    p.orientation.y]))
        
        else:
            g_tar = np.array([p.position.x,
                            p.position.y,
                            p.position.z,
                            p.orientation.x,
                            p.orientation.y])
    g_goal = [tr[0].pose.orientation.z, tr[0].pose.orientation.w]

def pos_callback(od):
    global g_pos
    p = od.pose.pose.position
    o = od.pose.pose.orientation
    v, w = od.twist.twist.linear.x, od.twist.twist.angular.z
    _, _, th = euler_from_quaternion(np.array([o.x, o.y, o.z, o.w]))

    g_pos = np.array([p.x, p.y, th, v, w])

if __name__ == "__main__":
    rospy.init_node('controller', anonymous=True)
    pub_vel = rospy.Publisher("/cmd_vel", Twist, queue_size=5)
    
    rospy.Subscriber("/dwa_trajectory", Path, callback)
    rospy.Subscriber("/odometry/filtered", Odometry, pos_callback)
    
    sleep(1)

    MV, MW = 0.3, 1.0
    vr = 0.3
    wr = 1.0
    A = [[0,   wr, 0 ],
         [-wr, 0,  vr],
         [0,   0,  0 ]]
    B = [[-1, 0],
         [0,  0],
         [0, -1]]
    p=np.array([-0.9, -0.99, -0.999])
    K = np.array(control.place(A,B,p))
    K = np.array([  [8.2413, -2.4646, -1.5918],
                    [-1.6649,  0.7984, 0.8683]  ])
    print(K)

    # target position
    xe = np.zeros(3)
    u = np.zeros(2)

    speed = Twist()
    r = rospy.Rate(1/T)

    try:
        while not rospy.is_shutdown():
            dist_to_goal = math.hypot(g_pos[0] - g_goal[0],
                                      g_pos[1] - g_goal[1])
            if dist_to_goal <= 0.6:
                speed.linear.x = 0
                speed.angular.z = 0
            else:
                speed.linear.x = u[0]
                speed.angular.z = u[1]

            print(len(g_tar), np.round(xe, 3), np.round(u, 2))

            pub_vel.publish(speed)
            r.sleep()

            if not g_tar.size:
                continue
        
            if len(g_tar) > 0 and len(g_tar.shape) > 1:
                if g_tar.size and (abs(xe) < 0.05).all():
                    g_tar = np.delete(g_tar, 0, 0)

                if not g_tar.size:
                    continue

                x = np.array([  g_tar[0,0] - g_pos[0],
                                g_tar[0,1] - g_pos[1],
                                g_tar[0,2] - g_pos[2] ])
                Vc = [g_tar[0,3], g_tar[0,4]]
            else:
                x = np.array([  g_tar[0] - g_pos[0],
                                g_tar[1] - g_pos[1],
                                g_tar[2] - g_pos[2] ])
                Vc = [g_tar[3], g_tar[4]]

            xe = np.array([ [np.cos(g_pos[2]),    np.sin(g_pos[2]), 0],
                            [-np.sin(g_pos[2]),   np.cos(g_pos[2]), 0],
                            [0,                 0,              1]  ])
            xe = xe@(x.T)
            
            #Vc = [g_pos[3], g_pos[4]]

            u = ((K)@(xe.T)).T + Vc

            u[0] = min(u[0], MV)
            u[0] = max(u[0], -MV)
            u[1] = min(u[1], MW)
            u[1] = max(u[1], -MW)      
                
    except KeyboardInterrupt:
        print("Force program termination")
        sys.exit()
    sys.exit()