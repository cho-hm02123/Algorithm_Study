import math, os, signal, sys, getpass
import numpy as np
import matplotlib.pyplot as plt

from geometry_msgs.msg import Twist, PoseStamped
import message_filters
from nav_msgs.msg import Path, Odometry
import rospy
from sensor_msgs.msg import PointCloud2
import sensor_msgs.point_cloud2 as pc2
from tf.transformations import euler_from_quaternion, quaternion_from_euler
import time
from time import sleep
from xproject.msg import Xproject

sys.path.append('/home/{}/PythonRobotics/PathPlanning/DynamicWindowApproach'.format(getpass.getuser()))
from dynamic_window_approach import *

ob = []
# initial state [x(m), y(m), yaw(rad), v(m/s), omega(rad/s)]
pos = np.array([0.0, 0.0, 0.0, 0.0, 0.0])
# goal position [x(m), y(m)]
goal = np.array([3.25, 0.75])*1.5

class jackal(Config):

    def __init__(self):
        super().__init__()

        self.max_speed = 0.3 #0.5
        self.min_speed = 0.0 #-1.0
        self.max_yaw_rate = 0.5
        self.max_accel = 20.0
        self.max_delta_yaw_rate = 25.0
        self.v_resolution = 0.1
        self.yaw_rate_resolution = 0.1

        self.dt = 0.25
        self.predict_time = 2.5 #0.5

        self.to_goal_cost_gain = 0.1 #0.05 # 0.15
        self.speed_cost_gain = 2.0
        self.obstacle_cost_gain = 0.25 #1.0


        self.robot_type = RobotType.rectangle

        self.robot_width = 0.5
        self.robot_length = 0.55

        self.robot_radius = 0.5 #1.0 #max(self.robot_width, self.robot_length)

def goal_callback(tar):
    global goal
    ratio = 1 #- 0.5/tar.distance
    goal = ratio * np.array([tar.pos_x, tar.pos_y])

    #rho = tar.distance
    #phi = -tar.angle*np.pi/180

def pos_callback(od):
    global pos
    p = od.pose.pose.position
    o = od.pose.pose.orientation
    v, w = od.twist.twist.linear.x, od.twist.twist.angular.z
    _, _, th = euler_from_quaternion(np.array([o.x, o.y, o.z, o.w]))

    pos = np.array([p.x, p.y, th, v, w])

def ob_callback(data):
    global ob
    if data.data != b'':
        ob = []
        for point in pc2.read_points(data, skip_nans=True):
            if len(ob):
                ob = np.vstack((ob, np.asarray(point[0:2])))
            else:
                ob = np.asarray(point[0:2])

def predict_trajectory(x_init, v, y, config):
    #x = np.array(x_init)
    time = 0.75
    x = np.array(motion(np.array(x_init), [v, y], time))
    trajectory = np.array(x)
    while time <= config.predict_time:
        x = motion(x, [v, y], config.dt)
        trajectory = np.vstack((trajectory, x))
        time += config.dt

    return trajectory

def calc_control_and_trajectory(pos, dw, config, goal, obstacle):
    pos_init = pos[:]
    min_cost = float("inf")
    best_u = [0.0, 0.0]
    best_trajectory = np.array([pos])
    # evaluate all trajectory with sampled input in dynamic window
    for v in np.arange(dw[0], dw[1], config.v_resolution):
        for w in np.arange(dw[2], dw[3], config.yaw_rate_resolution):

            trajectory = predict_trajectory(pos_init, v, w, config)

            # calc cost
            to_goal_cost = config.to_goal_cost_gain * \
                           calc_to_goal_cost(trajectory, goal)
            speed_cost = config.speed_cost_gain * \
                         (config.max_speed - trajectory[-1, 3])

            ob_cost = 0
            if len(obstacle) > 0 and len(obstacle.shape) > 1:
                ob_cost = config.obstacle_cost_gain * \
                      calc_obstacle_cost(trajectory, obstacle, config)

            final_cost = to_goal_cost + ob_cost + speed_cost

            # search minimum trajectory
            if min_cost >= final_cost:
                min_cost = final_cost
                best_u = [v, w]
                best_trajectory = trajectory
                '''
                if abs(best_u[0]) < config.robot_stuck_flag_cons \
                        and abs(pos[3]) < config.robot_stuck_flag_cons:
                    # to ensure the robot do not get stuck in
                    # best v=0 m/s (in front of an obstacle) and
                    # best omega=0 rad/s (heading to the goal with
                    # angle difference of 0)
                    best_u[1] = -config.max_delta_yaw_rate
                '''

    return best_u, best_trajectory

def signal_handler(sig, frame):
    print("\n[ KeyboardInterrupt ]\n")
    os.system('killall -9 python3')
    sys.exit(0) 

signal.signal(signal.SIGINT, signal_handler)

def main(show=False):
    global ob, pos, goal

    config = jackal()

    rospy.init_node('dwa_node', anonymous=True)
    #pub_vel = rospy.Publisher("/cmd_vel", Twist, queue_size=5)
    pub_traj = rospy.Publisher("dwa_trajectory", Path, queue_size=5)

    #rospy.Subscriber("/odometry/filtered", Odometry, pos_callback)
    rospy.Subscriber("/voxel_pointcloud", PointCloud2, ob_callback)
    rospy.Subscriber("Xproject", Xproject, goal_callback)
    sleep(1)

    #trajectory = np.array([pos])

    BOX = 2

    try:
        while not rospy.is_shutdown():
            time_now = time.time()
            #trajectory = np.vstack((trajectory, pos))
            dw = calc_dynamic_window(pos, config)
            u, predicted_trajectory = \
                calc_control_and_trajectory(pos, dw, config, goal, ob)
            print("[{}]".format(time_now), np.round(predicted_trajectory[0, :], 2),np.round(u, 2))

            if show:
                plt.figure(1)
                plt.cla()
                plot_arrow(pos[0], pos[1], pos[2], length=config.robot_length/2)
                plot_robot(pos[0], pos[1], pos[2], config)
                plt.plot(predicted_trajectory[:, 0], 
                        predicted_trajectory[:, 1], '-r')
                plt.plot(goal[0], goal[1], 'xb')
                if len(ob) > 0 and len(ob.shape) > 1:
                    plt.plot(ob[:,0], ob[:,1], 'ok')
                plt.grid(True)
                plt.pause(0.0001)

            path = Path()
            for state in predicted_trajectory:
                pose = PoseStamped()
                [   
                    pose.pose.position.x,
                    pose.pose.position.y,
                    pose.pose.position.z,
                    pose.pose.orientation.x,
                    pose.pose.orientation.y 
                ] = state
                [
                    pose.pose.orientation.z,
                    pose.pose.orientation.w
                ] = goal
                path.poses.append(pose)

            pub_traj.publish(path)  
        
        '''
        if show:
            plt.plot(trajectory[:, 0], trajectory[:, 1], "-r")
            plt.show()
            #u, predicted_trajectory = dwa_control(pos, config, goal,
            #                                           obstacle)
        '''
    except KeyboardInterrupt:
        print("Force program termination")
        sys.exit()
    sys.exit()


if __name__ == "__main__":
    main(show=True)