#!/usr/bin/env python3
import time
from math import atan2, sqrt, pi, degrees, asin
import rospy
from geometry_msgs.msg import Twist, Point, Pose, Quaternion, PoseStamped
from nav_msgs.msg import Path, Odometry
from tf.transformations import euler_from_quaternion, quaternion_from_euler
from time import sleep
import message_filters

import numpy as np
import os, signal, sys, math

# ========================= #
# 전역 상수는 이곳에
T = 0.01
# ========================= #
# 전역 변수는 이곳에
g_pos = np.array([0.0, 0.0, 0.0])
g_tar = []
g_goal = []
g_vc = np.zeros(2)
g_time = 0
g_new_path = False
# ========================= #
# 키보드 인터럽트를 통해 파이썬 실행 파일이 모두 종료
def signal_handler(sig, frame):
    print("\n[ KeyboardInterrupt ]\n")
    os.system('killall -9 python3')
    sys.exit(0) 

signal.signal(signal.SIGINT, signal_handler)
# ========================= #
# 콜백 함수
def path_callback(path):
    global g_tar, g_time, g_new_path

    tr = path.poses

    if len(tr) > 0:
        g_tar = []

    for t in tr:
        p = t.pose.position
        o = t.pose.orientation
        _, _, th_ = euler_from_quaternion(np.array([o.x, o.y, o.z, o.w]))

        g_tar.append([p.x, p.y, th_])

    g_time = time.time()
    g_new_path = True

def speed_callback(speed):
    global g_vc

    v = speed.linear.x
    w = speed.angular.z

    g_vc = np.array([v, w])

def pos_callback(od):
    global g_pos
    p = od.pose.pose.position
    o = od.pose.pose.orientation
    _, _, th = euler_from_quaternion(np.array([o.x, o.y, o.z, o.w]))

    g_pos = np.array([p.x, p.y, th])

def goal_callback(od):
    global g_goal
    p = od.pose.position
    o = od.pose.orientation
    _, _, th = euler_from_quaternion(np.array([o.x, o.y, o.z, o.w]))

    g_goal = np.array([p.x, p.y, th])
# ========================= #
if __name__ == "__main__":
    rospy.init_node('controller', anonymous=True)
    pub_vel = rospy.Publisher("/cmd_vel", Twist, queue_size=5)
    
    # rospy.Subscriber("/dwa_trajectory", Path, callback)
    # rospy.Subscriber("/odometry/filtered", Odometry, pos_callback)
    #sub_path = message_filters.Subscriber("/move_base/TrajectoryPlannerROS/local_plan", Path)
    #sub_vel = message_filters.Subscriber("/move_base/cmd_vel", Twist)
    rospy.Subscriber("/move_base/TrajectoryPlannerROS/local_plan", Path, path_callback)
    rospy.Subscriber("/move_base/cmd_vel", Twist, speed_callback)
    rospy.Subscriber("/cmd_pose", Odometry, pos_callback)
    rospy.Subscriber("/move_base/current_goal", PoseStamped, goal_callback)
    #ts = message_filters.ApproximateTimeSynchronizer([sub_path, sub_vel], 10, 0.5, allow_headerless=True)
    #ts.registerCallback(callback)

    sleep(1)

    MV, MW = 0.5, 1.0

    K1 = np.array([ [0.2954, -0.0000, -0.0000],
                    [0.0000, 0.5975, 0.4121]    ])
    K2 = np.array([ [0.2954, -0.0000, -0.0000],
                    [0.0000, 0.5975, 0.4121]  ])

    # target position
    xe = np.zeros(3)
    u = np.zeros(2)
    tar = []
    g_goal = g_pos

    speed = Twist()
    r = rospy.Rate(1/T)

    while not rospy.is_shutdown():
        pos = g_pos

        #새로운 경로를 받으면 기존 목표로 하던 좌표를 버림
        if g_new_path:
            g_new_path = False
            tar = []

        # 경로를 받은지 3초가 지나면 기존 경로 및 목표 좌표를 버림
        # 왜? 한 번에 받는 경로는 최대 2초까지 갈 수 있는 경로를 의미하기 때문에
        # 3초가 지난 시점에서는 오류로 간주함
        if abs(time.time() - g_time) > 3.0:
            g_tar = []
            
        # 제공받은 경로가 존재
        if len(g_tar) > 0:
            # 목표 지점이 없거나 현재 위치와 목표 지점이 근접하면
            # 새로운 목표 지점을 경로에서 갱신받음
            if not tar or (abs(pos - tar)[0:2] < 0.25).all():
                cur = g_tar.pop(0)
                tar = cur
        #else:
            # 제공받은 경로가 없으면 목표 지점을 비움
            #tar = []

        if g_vc[0] <= 0:
            u = g_vc
            #u[1] = np.clip(u[1], -0.5, 0.5)
        elif tar:
            # 제어기 넣는 부분
            # u = [v, w]로 대입

            x = np.array([  tar[0] - pos[0],
                            tar[1] - pos[1],
                            tar[2] - pos[2] ])

            if x[2] > np.pi:
                x[2] = x[2] - 2*np.pi
            elif x[2] < -np.pi:
                x[2] = x[2] + 2*np.pi
            
            xe = np.array([ [np.cos(pos[2]),  np.sin(pos[2]), 0],
                            [-np.sin(pos[2]), np.cos(pos[2]), 0],
                            [0,               0,              1]  ])
            xe = xe@(x.T)

            member_func_1 = (1+g_vc[1])*0.5
            member_func_2 = (1-g_vc[1])*0.5

            u = (member_func_1*K1+member_func_2*K2)@xe + g_vc
            
            #u = g_vc
        else:
            # 제공받은 경로를 모두 사용했거나 목표로 하는 좌표가 없으면
            # 이 부분이 실행됨, 마지막 위치에서의 자세 제어는 이 부분에 ?

            u = [0, 0]
            #u = g_vc

        # 목표에 일정 거리만큼 도착하면 정지
        '''
        dist_to_goal = math.hypot(pos[0] - g_goal[0],
                                    pos[1] - g_goal[1])
        if dist_to_goal <= 0.3:
            u[0] = 0
            g_goal = pos
        '''
        # 속도, 가속도 제한 / 매개변수 : 1. 변수 2. 최소값 3. 최대값
        #u = np.clip(u, [-MV, -MW], [MV, MW])
        [speed.linear.x, speed.angular.z] = u

        # 경로를 받은 시각, 경로 개수 , 현재 위치 , 목표 위치 , 현재 속도 , 목표 속도
        print("| {} |".format(np.round(g_time, 2)) , len(g_tar), np.round(pos, 3), np.round(tar, 3), np.round(u, 2), np.round(g_vc, 2))

        pub_vel.publish(speed)
        r.sleep()
