import sys
import os
import time
import numpy as np
from math import atan2, sqrt, pi, degrees, asin
import rospy
from std_msgs.msg import String, Header, Float64
from geometry_msgs.msg import Twist, Point, Pose, Quaternion, PoseStamped
from nav_msgs.msg import Odometry
from xproject.msg import Xproject
from tf.transformations import euler_from_quaternion, quaternion_from_euler
import message_filters
from time import sleep

T = 0.01
K1, K2 = 0.2, 0.3
POINT = 2
# ========================= #
cx, cy, th = 0, 0, 0
rho, phi = 0, 0
# ========================= #
def callback(pos, tar):
    global cx, cy, th, rho, phi
    
    curr_p = pos.pose.pose.position
    curr_o = pos.pose.pose.orientation
    cx, cy = curr_p.x, curr_p.y
    _, _, th = euler_from_quaternion(np.array([curr_o.x, curr_o.y, curr_o.z, curr_o.w]))

    rho = tar.distance
    phi = -tar.angle*np.pi/180

    # print(g_x, g_y)

if __name__ == "__main__":
    rospy.init_node('controller', anonymous=True)
    pub_vel = rospy.Publisher("/cmd_vel", Twist, queue_size=5)
    # pos = rospy.Subscriber("/jackal_velocity_controller/odom", Odometry, callback) # 엔코더 데이터
    # pos = rospy.Subscriber("/odometry/filtered", Odometry, callback)  # imu 보정을 통한 데이터

    sub_pos = message_filters.Subscriber("/odometry/filtered", Odometry)
    sub_tar = message_filters.Subscriber("Xproject", Xproject)
    ts = message_filters.ApproximateTimeSynchronizer([sub_pos, sub_tar], 20, 0.5, allow_headerless=True)
    ts.registerCallback(callback)
    sleep(1)
    
    speed = Twist()
    r = rospy.Rate(1/T)

    #rx, ry, case = 0.5, 0, 0
    try:
        while not rospy.is_shutdown(): 
            print(np.round(cx, POINT), np.round(cy, POINT),
                  np.round(th*180/np.pi, POINT), np.round(phi*180/np.pi, POINT))

            '''
            if case == 0 and cx > 0.49:
                case = 1
                rx, ry = 0.5, 0.5

            rho = np.sqrt((rx + 0.1)**2 + ry**2)
            psi = np.arctan2(ry, rx + 0.1)
            phi = th - psi

            if phi > np.pi:
                phi = phi - 2*np.pi

            if phi < -np.pi:
                phi = phi + 2*np.pi
            '''

            vr = K1*rho*np.cos(phi)
            wr = -K1*np.sin(phi)*np.cos(phi)-K2*phi

            if vr > 0.25:
                vr = 0.25
            elif vr < -0.25:
                vr = -0.25

            if wr > 0.7:
                wr = 0.7
            elif wr < -0.7:
                wr = -0.7

            speed.linear.x = vr
            speed.angular.z = wr

            pub_vel.publish(speed)

            r.sleep()

    except KeyboardInterrupt:
        print("Force program termination")
        sys.exit()
    sys.exit()

